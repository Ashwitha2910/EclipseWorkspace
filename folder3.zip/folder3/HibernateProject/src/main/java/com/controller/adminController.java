package com.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.dao.HotelDao;
import com.entities.Booking;
import com.entities.Customer;
import com.entities.Rooms;
import com.view.UpdateMenu;
import com.view.UpdateRooms;

public class adminController {
	static Configuration conf=HotelDao.getHotelObject();
	static Customer cust=new Customer();
	static Booking b=new Booking();
	
	public static void addCustomer()
	{
		SessionFactory sf=conf.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter customer name: ");
		String cust_name=input.next();
		
		System.out.println("Enter customer age: ");
		int cust_age=input.nextInt();
		
		System.out.println("Enter customer address: ");
		String cust_address=input.next();
		
		System.out.println("Enter customer contact number: ");
		long cust_num=input.nextLong();
		
		System.out.println("Enter customer email: ");
		String cust_email=input.next();
		
		cust.setCust_name(cust_name);
		cust.setCust_age(cust_age);
		cust.setCust_address(cust_address);
		cust.setMobile_no(cust_num);
		cust.setCust_email(cust_email);
		s.save(cust);
		t.commit();
		System.out.println("Customer Added successfully..");
	}
	
	public static void updateCustomer()
	{
		UpdateMenu um=new UpdateMenu();
		um.handleMenu();
	}
	
	public static void deleteCustomer()
	{

		SessionFactory sf=conf.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Id to delete Customer: ");
		int cust_id=input.nextInt();
		
		Query q=s.createQuery("delete from Customer where cust_id=:i");
		q.setParameter("i", cust_id);
		int status=q.executeUpdate();
		System.out.println(status+" Rows deleted");
		t.commit();
	}
	
	public static void displayCustomers()
	{
		SessionFactory sf=conf.buildSessionFactory();
		Session s=sf.openSession();
		TypedQuery query=s.createQuery("from Customer");
		List<Customer> list=query.getResultList();
		Iterator<Customer> itr=list.iterator();
		while(itr.hasNext())
		{
			Customer cst=itr.next();
			System.out.println("Name= "+cst.getCust_name()+" --Age= "+cst.getCust_age()+" -- Address= "+cst.getCust_address()
			+" --Mobile= "+cst.getMobile_no()+" --Email= "+cst.getCust_email());
		}
	}
	
	public static void searchCustomer() {
		SessionFactory sf=conf.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Id to search Customer: ");
		int cust_id=input.nextInt();
		
		Customer getCust=s.get(Customer.class, new Integer(cust_id));
		if(getCust!=null) {
		System.out.println("Customer id: "+getCust.getCust_id());
		System.out.println("Customer name: "+getCust.getCust_name());
		System.out.println("Customer Address: "+getCust.getCust_address());
		System.out.println("Customer Mobile number: "+getCust.getMobile_no());
		System.out.println("Customer email: "+getCust.getCust_email());
		}
		else
			System.out.println("Id not found");
		t.commit();
	}
	
//	public static void allocateRoom() {
//		SessionFactory sf=conf.buildSessionFactory();
//		Session s=sf.openSession();
//		Transaction t=s.beginTransaction();
//		Scanner input=new Scanner(System.in);
//		System.out.println("Enter Id to search Customer: ");
//		int cust_id=input.nextInt();
//		
//		
//	}
	
	public static void displayRooms()
	{
		SessionFactory sf=conf.buildSessionFactory();
		Session s=sf.openSession();
		TypedQuery query=s.createQuery("from Rooms");
		List<Rooms> list=query.getResultList();
		Iterator<Rooms> itr=list.iterator();
		while(itr.hasNext())
		{
			Rooms rms=itr.next();
			System.out.println("Room no: "+rms.getRoom_no()+" -- Room type: "+rms.getRoom_type()+" -- Room Fare: "
					+rms.getRoom_fare()+" -- Ac: "+rms.getAc_avlaibility()+" -- Room Avilability: "+rms.getRoom_availability());
		}
	}
	
	public static void updateRoom()
	{
		UpdateRooms ur=new UpdateRooms();
		ur.handleMenu();
	}
	
	public static void displayBookingDetails()
	{
		SessionFactory sf=conf.buildSessionFactory();
		Session s=sf.openSession();
		TypedQuery query=s.createQuery("from Booking");
		List<Booking> list=query.getResultList();
		Iterator<Booking> itr=list.iterator();
		while(itr.hasNext())
		{
			Booking bkg=itr.next();
			System.out.println("Booking id: "+bkg.getBooking_id()+" -- Booking Date: "+bkg.getBooking_date()+" -- Customer name: "
					+bkg.getCust_name()+" -- Customer Phone: "+bkg.getPhone()+" -- Room no: "+bkg.getRoom_no()+" -- No of Days: "+bkg.getDaysToHireFor()+
					" -- Fare: "+bkg.getFare()+" -- Bill: "+bkg.getBill());
		}
	}
	
	public static void bookingRoom()
	{
		SessionFactory sf=conf.buildSessionFactory();
		Session s=sf.openSession();
		Transaction tran=s.beginTransaction();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter booking date: ");
		String booking_date=input.next();
		
		System.out.println("Enter Customer name: ");
		String cust_name=input.next();
		
		System.out.println("Enter Customer Contact number: ");
		long cust_mobile=input.nextLong();
		
		System.out.println("Enter room no: ");
		int room_no=input.nextInt();
		
		System.out.println("Enter No of days: ");
		int days=input.nextInt();
		
		System.out.println("Enter fare: ");
		float fare=input.nextFloat();
		
		System.out.println("Enter bill: ");
		float bill=input.nextFloat();
		
		b.setBooking_date(booking_date);
		b.setCust_name(cust_name);
		b.setPhone(cust_mobile);
		b.setRoom_no(room_no);
		b.setDaysToHireFor(days);
		b.setFare(fare);
		b.setBill(bill);
		s.save(b);
		tran.commit();
		System.out.println("Your Booking is confirmed..");
	}
}
