package com.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Rooms")
public class Rooms {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="room_no")
	private int room_no;
	@Column(name="room_type")
	private String room_type;
	@Column(name="room_fare")
	private float room_fare;
	@Column(name="room_ac")
	private String ac_avlaibility;
	@Column(name="room_Availability")
	private String room_availability;
	public int getRoom_no() {
		return room_no;
	}
	public void setRoom_no(int room_no) {
		this.room_no = room_no;
	}
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public float getRoom_fare() {
		return room_fare;
	}
	public void setRoom_fare(float room_fare) {
		this.room_fare = room_fare;
	}
	public String getAc_avlaibility() {
		return ac_avlaibility;
	}
	public void setAc_avlaibility(String ac_avlaibility) {
		this.ac_avlaibility = ac_avlaibility;
	}
	public String getRoom_availability() {
		return room_availability;
	}
	public void setRoom_availability(String room_availability) {
		this.room_availability = room_availability;
	}
	
	
}
