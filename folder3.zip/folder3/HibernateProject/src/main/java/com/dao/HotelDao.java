package com.dao;
import org.hibernate.cfg.Configuration;
public class HotelDao {
	
			public static Configuration getHotelObject()
		{
			Configuration conf=new Configuration();
			conf.configure();
			return conf;
		}
	}

