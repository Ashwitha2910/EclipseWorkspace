package com.view;

import java.util.Scanner;

import com.controller.adminController;

public class Menu {
	public void displayMenu() {
		System.out.println("--------------------------------------");
        String[] mItems= {
                "Add Customer",
                "Delete Customer",
                "Update Customer",
                "Search Customer",
                "Display all Customers",
                "Update Rooms",
                "Book a room for customer",
                "Diplay Room Details",
                "Display Booking Details",
                "Exit"
        };

        for(int i=0;i<mItems.length;i++) {
            System.out.println((i+1)+"."+mItems[i]);
        }
    }
	
	public int promptForChoice() {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your choice:");
        int ch=sc.nextInt();
        return ch;
    }
	
	 public void handleMenu() {
	        while(true) {
	            this.displayMenu();
	            int ch=this.promptForChoice();
	            adminController cc=new adminController();

	            switch(ch) {
	            case 1:cc.addCustomer();
	                break;
	            case 2:cc.deleteCustomer();
	                 break;
	            case 3:cc.updateCustomer();
                	 break;
	            case 4:cc.searchCustomer();
                   	 break;
	            case 5:cc.displayCustomers();
                	 break;
	            case 6:cc.updateRoom();
	            	 break;
	            case 7:cc.bookingRoom();;
      	 		 break;
	            case 8:cc.displayRooms();
           	 		 break;
	            case 9:cc.displayBookingDetails();
      	 		     break;
	            case 10:System.exit(0);
	            }
	        }

	    }
}
