package com.view;

import java.util.Scanner;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.controller.adminController;
import com.dao.HotelDao;
import com.entities.Customer;


public class UpdateMenu {
	
	static Configuration conf=HotelDao.getHotelObject();
	static Customer cust=new Customer();
	
	public void displayMenu() {
        String[] mItems= {
                "Name",
                "Age",
                "Address",
                "Contact Number",
                "Email",
                "Exit"
        };

        for(int i=0;i<mItems.length;i++) {
            System.out.println((i+1)+"."+mItems[i]);
        }
    }
	
	public int promptForChoice() {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your choice:");
        int ch=sc.nextInt();
        return ch;
    }
	
	 public void handleMenu() {
	        while(true) {
	            this.displayMenu();
	            int ch=this.promptForChoice();
	            SessionFactory sf=conf.buildSessionFactory();
				Session s=sf.openSession();
	    		Transaction t=s.beginTransaction();
	    		Scanner input=new Scanner(System.in);
	    		adminController aa=null;

	            switch(ch) {
	            case 1: System.out.println("Enter Id to update Customer Details: ");
			    		int cust_id=input.nextInt();
	    		        System.out.println("Enter new Name: ");
	    		        String cust_name=input.next();
	    		        Query q=s.createQuery("update Customer set cust_name=:n where cust_id=:i");
	    				q.setParameter("i", cust_id);
	    				q.setParameter("n", cust_name);
	    				q.executeUpdate();
	    				System.out.println(" Customer name updated");
	                break;
		         case 2: System.out.println("Enter Id to update Customer Details: ");
				    	 int cus_id=input.nextInt();
				         System.out.println("Enter new age: ");
				        String cust_age=input.next();
				        Query q1=s.createQuery("update Customer set cust_age=:n where cust_id=:i");
						q1.setParameter("i", cus_id);
						q1.setParameter("n", cust_age);
						q1.executeUpdate();
						System.out.println("Customer age updated");
	                 break;  
	            case 3:System.out.println("Enter Id to update Customer Details: ");
			    		int cu_id=input.nextInt();
	            		System.out.println("Enter new address: ");
				        String cust_address=input.next();
				        Query q2=s.createQuery("update Customer set cust_address=:n where cust_id=:i");
						q2.setParameter("i", cu_id);
						q2.setParameter("n", cust_address);
						q2.executeUpdate();
						System.out.println("Customer aaddress updated");
	                 break;
	            case 4:System.out.println("Enter Id to update Customer Details: ");
			    		int c_id=input.nextInt();
	            	    System.out.println("Enter new contact number: ");
				        long cust_num=input.nextLong();
				        Query q3=s.createQuery("update Customer set cust_address=:n where cust_id=:i");
						q3.setParameter("i", c_id);
						q3.setParameter("n", cust_num);
						q3.executeUpdate();
						System.out.println("Customer Contact number updated");
	                 break;
	            case 5:
		            	System.out.println("Enter Id to update Customer Details: ");
			    		int custt_id=input.nextInt();
			            System.out.println("Enter new email: ");
				        String cust_email=input.next();
				        Query q4=s.createQuery("update Customer set cust_address=:n where cust_id=:i");
						q4.setParameter("i", custt_id);
						q4.setParameter("n", cust_email);
						q4.executeUpdate();
						System.out.println("Customer email updated");
	                 break;
	            case 6:Menu m=new Menu();
	            	   m.handleMenu();
	            	   break;
	            }
	            t.commit();
	        }

	    }
}
