package com.view;

import java.util.Scanner;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.controller.adminController;
import com.dao.HotelDao;
import com.entities.Customer;

public class UpdateRooms {
	static Configuration conf=HotelDao.getHotelObject();
	static Customer cust=new Customer();
	
	public void displayMenu() {
        String[] mItems= {
                "Room type",
                "Room fare",
                "AC availability",
                "Room Availability",
                "Exit"
        };

        for(int i=0;i<mItems.length;i++) {
            System.out.println((i+1)+"."+mItems[i]);
        }
    }
	
	public int promptForChoice() {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your choice:");
        int ch=sc.nextInt();
        return ch;
    }
	
	 public void handleMenu() {
	        while(true) {
	            this.displayMenu();
	            int ch=this.promptForChoice();
	            SessionFactory sf=conf.buildSessionFactory();
				Session s=sf.openSession();
	    		Transaction t=s.beginTransaction();
	    		Scanner input=new Scanner(System.in);
	    		adminController aa=null;

	            switch(ch) {
	            case 1: System.out.println("Enter Room No to update Room Details: ");
			    		int room_no=input.nextInt();
	    		        System.out.println("Enter updated Room type: ");
	    		        String room_type=input.next();
	    		        Query q=s.createQuery("update Rooms set room_type=:n where room_no=:i");
	    				q.setParameter("i", room_no);
	    				q.setParameter("n", room_type);
	    				q.executeUpdate();
	    				System.out.println(" Room details updated");
	                break;
		         case 2: System.out.println("Enter Room no to update Room Details: ");
				    	 int roo_no=input.nextInt();
				         System.out.println("Enter new Fare: ");
				        float fare=input.nextFloat();
				        Query q1=s.createQuery("update Rooms set room_fare=:n where room_no=:i");
						q1.setParameter("i", roo_no);
						q1.setParameter("n", fare);
						q1.executeUpdate();
						System.out.println("Room Fare updated");
	                 break;  
	            case 3:System.out.println("Enter Room no to update Room Details: ");
		    	 		int ro_no=input.nextInt();
	            		System.out.println("Enter ac Availability: ");
				        String ac=input.next();
				        Query q2=s.createQuery("update Rooms set room_ac=:n where ro_no=:i");
						q2.setParameter("i", ro_no);
						q2.setParameter("n", ac);
						q2.executeUpdate();
						System.out.println("Room ac details updated");
	                 break;
	            case 4:System.out.println("Enter Room no to update Room Details: ");
	            		int r_no=input.nextInt();
	            	    System.out.println("Enter new room status  ");
				        String r_availability=input.next();
				        Query q3=s.createQuery("update Rooms set room_Availability=:n where room_no=:i");
						q3.setParameter("i", r_no);
						q3.setParameter("n", r_availability);
						q3.executeUpdate();
						System.out.println("Room availabilty details updated");
	                 break;
	            
	            case 5:Menu m=new Menu();
	            	   m.handleMenu();
	            	   break;
	            }
	            t.commit();
	        }

	    }
}
