package com.model;

public class StudentErrorResponse {
	private int status_code;
	private String message;
	private long timestamp;
	public int getStatus_code() {
		return status_code;
	}
	public void setStatus_code(int status_code) {
		this.status_code = status_code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	public StudentErrorResponse(int status_code, String message, long timestamp) {
		super();
		this.status_code = status_code;
		this.message = message;
		this.timestamp = timestamp;
	}
	public StudentErrorResponse() {
		super();
	}
	
	
}
