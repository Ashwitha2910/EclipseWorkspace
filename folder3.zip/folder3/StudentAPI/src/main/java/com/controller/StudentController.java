package com.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.function.EntityResponse;

import com.config.StudentNotFoundException;
import com.model.Student;
import com.model.StudentErrorResponse;

@RestController
@RequestMapping("/api")
public class StudentController implements InitializingBean {
	static List<Student> list;
	
//	@ExceptionHandler
//	public ResponseEntity<StudentErrorResponse> handleException(StudentNotFoundException ex){
//		StudentErrorResponse sterror=new StudentErrorResponse();
//		sterror.setStatus_code(HttpStatus.NOT_FOUND.value());
//		sterror.setMessage(ex.getMessage());
//		sterror.setTimestamp(System.currentTimeMillis());
//		return new ResponseEntity(sterror,HttpStatus.NOT_FOUND);
//	}
	
	public void afterPropertiesSet() throws Exception {
		System.out.println("Bhushan");
		list=new ArrayList<Student>();
		list.add(new Student("John","Cena"));
		list.add(new Student("Dean","Ambrose"));
		list.add(new Student("Suksham","Sukhi"));
		list.add(new Student("Shravan","Kumar"));
		list.add(new Student("Ashwitha","Prabhu"));
		System.out.println(list);
		
	}
//	
//	@PostConstruct
//	public void load() {
//		System.out.println("Bhushan");
//		list=new ArrayList<Student>();
//		list.add(new Student("John","Cena"));
//		list.add(new Student("Dean","Ambrose"));
//		list.add(new Student("Suksham","Sukhi"));
//		list.add(new Student("Shravan","Kumar"));
//		list.add(new Student("Ashwitha","Prabhu"));
//		System.out.println(list);
//		
//	}
	
	@GetMapping("/students")
	public List<Student> getStudents()
	{
		return list;
	}
	
	@GetMapping("/students/{stid}")
	public Student getStudent(@PathVariable int stid)
	{
		return list.get(stid);
	}
	
	@PostMapping("/student")
	public Student addStudent(@RequestBody Student student)
	{
		list.add(student);
		return student;
	}
	
	@DeleteMapping("/students/{stid}")
	public void deleteStudent(@PathVariable int stid)
	{
		list.remove(stid);
	}
	
	@PutMapping("/students/{stid}")
	public void updateStudent(@PathVariable int stid)
	{
		Student sd=list.get(stid);
		sd.setFirst_name("Ankitha");
		sd.setLast_name("Prabhu");
	}

	
}
