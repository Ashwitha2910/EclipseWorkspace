
public class SmallBusinessLoan extends BusinessLoan {

	
	public SmallBusinessLoan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SmallBusinessLoan(double loanAmount, int tenure) {
		super(loanAmount, tenure);
		// TODO Auto-generated constructor stub
	}

	@Override
	public float getInterestRate() {
		// TODO Auto-generated method stub
		return 0.32f;
	}

}
