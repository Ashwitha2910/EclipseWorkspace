
public class Square {
	private final int size;

	public Square(int size) {
		super();
		this.size = size;
	}

	public int getSize() {
		return size;
	}

	Square enLarge(int bySize)
	{
//		this.size=this.size+bySize;
		Square temp=new Square(this.size+bySize);
		return temp;
	}
	@Override
	public String toString() {
		return "Square [size=" + size + "]";
	}
	
	
}
