
public class SquareClient {

	public static void main(String[] args) {
		Square s1=new Square(10);
		System.out.println("The size of the square is: "+s1.getSize());
		System.out.println(s1.toString());
		System.out.println(s1);
		
		Square s2=s1.enLarge(20);
		System.out.println(s2);
		Square s3=s2.enLarge(20);
		System.out.println(s3);
		System.out.println(s3.enLarge(5));
	}

}
