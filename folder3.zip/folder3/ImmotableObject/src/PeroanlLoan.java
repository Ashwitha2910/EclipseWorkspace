
public class PeroanlLoan extends Loan{

	public PeroanlLoan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PeroanlLoan(double loanAmount, int tenure) {
		super(loanAmount, tenure);
		// TODO Auto-generated constructor stub
	}

	@Override
	public float getInterestRate() {
		// TODO Auto-generated method stub
		return 0.2f;
	}

}
