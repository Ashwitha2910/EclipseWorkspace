
public class HomeLoan extends Loan {
	public HomeLoan(double loanAmount,int tenure)
	{
		super(loanAmount,tenure);
	}

	@Override
	public float getInterestRate() {
		
		return 0.07f;
	}
	
}
