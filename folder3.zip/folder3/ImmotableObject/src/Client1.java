
public class Client1 {
public static void main(String[] args) {
	Loan hl=new HomeLoan(2000,10);
	System.out.println(hl.getInterestRate());
	System.out.println(hl.getInterestAmount());
	
	hl=new CarLoan(5000,10);
	System.out.println(hl.getInterestRate());
	System.out.println(hl.getInterestAmount());
	
	hl=new PeroanlLoan(5000,10);
	System.out.println(hl.getInterestRate());
	System.out.println(hl.getInterestAmount());
	
	hl=new SmallBusinessLoan(5000,10);
	System.out.println("SmallBusiness InterestRate "+hl.getInterestRate());
	System.out.println("SmallBusiness Amount "+hl.getInterestAmount());
}
}
