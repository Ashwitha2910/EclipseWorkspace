//Concrete class
abstract public class Loan {
	private double loanAmount;
	private int tenure;
	
	public Loan() {
		super();
	}

	public Loan(double loanAmount, int tenure) {
		super();
		this.loanAmount = loanAmount;
		this.tenure = tenure;
	}
	
	abstract public float getInterestRate();
//	{
//		return 0.0f;
//	}
	
	public double getInterestAmount()
	{
		return this.loanAmount*this.tenure*this.getInterestRate();
	}
}
