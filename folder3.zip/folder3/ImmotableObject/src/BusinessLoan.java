
abstract public class BusinessLoan extends Loan {

	public BusinessLoan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BusinessLoan(double loanAmount, int tenure) {
		super(loanAmount, tenure);
		// TODO Auto-generated constructor stub
	}
	
}
