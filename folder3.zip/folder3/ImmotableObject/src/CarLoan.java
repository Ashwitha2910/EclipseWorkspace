
public class CarLoan extends Loan {

	public CarLoan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CarLoan(double loanAmount, int tenure) {
		super(loanAmount, tenure);
	}

	@Override
	public float getInterestRate() {
		
		return 0.12f;
	}
	
}
