
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 A obj1=new A();
	     System.out.println(obj1.i);
	     obj1.f1();
	      
	     B obj2=new B();
	     System.out.println(obj2.i);
         System.out.println(obj2.j);
         obj2.f1();
         obj2.f2();
	}

}
