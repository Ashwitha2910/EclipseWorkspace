
public class B extends A{
	  int j;
	    
	    void f2() {
	        System.out.println("f2 in B");
	        System.out.println(j);
	        System.out.println(i);
	    }
}
