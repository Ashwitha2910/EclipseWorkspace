
public class A {
	 protected int i;
	    
	    void f1() {
	        System.out.println("f1 in A");
	        System.out.println(i);
	    }
}
