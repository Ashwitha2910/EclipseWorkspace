package com.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.model.Product;

public class ProductDaoImpl implements ProductDao{

	private JdbcTemplate jdbcTemplate;
	
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insertProduct(Product product) {
		String query="insert into Product values(?,?,?)";
		int res=this.jdbcTemplate.update(query,product.getPid(),product.getPname(),product.getPprice());
		return res;
	}

	public int updateProduct(Product product) {
		String query="update Product set pname=?,pprice=? where pid=?";
		int res=this.jdbcTemplate.update(query,product.getPname(),product.getPprice(),product.getPid());
		return res;
	}

	public int deleteProduct(Product product) {
		String query="delete from Product where pid=?";
		int res=this.jdbcTemplate.update(query,product.getPid());
		return res;
	}

	public Product getProduct(int pid) {
		String query="select * from Product where pid=?";
		RowMapper<Product> rm=new RowMapperImpl();
		Product prod=this.jdbcTemplate.queryForObject(query,rm,pid);
		return prod;
	}

	public List<Product> getAllProduct() {
		String query="select * from Product";
		RowMapper<Product> rm=new RowMapperImpl();
		List<Product> l=this.jdbcTemplate.query(query, rm);
		return l;
	}

}
