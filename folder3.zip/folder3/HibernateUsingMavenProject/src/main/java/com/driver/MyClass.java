package com.driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.entities.CustomerDetails;

public class MyClass {

	public static void main(String[] args) {
		CustomerDetails obj=new CustomerDetails();
		Configuration config=new Configuration();
		config.configure();
		
		SessionFactory sf=config.buildSessionFactory();
		Session session= sf.openSession();
		Transaction tran= session.beginTransaction();
		obj.setCname("Sharanya");
		obj.setCaddress("Puttur");
		session.save(obj);
		tran.commit();
	}

}
