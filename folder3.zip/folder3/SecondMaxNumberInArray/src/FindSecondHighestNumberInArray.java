
public class FindSecondHighestNumberInArray {

	public static void main(String[] args) {
		int[] array= {2,3,4,5,6,7,9};
		int max=0;
		int secondMax=0;
		for(int i=0;i<array.length;i++) {
			if(array[i]>max) {
				secondMax=max;
				max=array[i];
			}
			else if(array[i]>secondMax)
			{
				secondMax=array[i];
			}
		}
		System.out.println(secondMax);
	}

}
