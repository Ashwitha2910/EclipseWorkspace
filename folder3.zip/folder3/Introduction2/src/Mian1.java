
public class Mian1 {

	public static void main(String[] args) {
		 int a=100;
		 int[] marks;//array declaration, No size is given
		 marks=new int[3];//initialization of array
		 marks[0]=29;
		 marks[1]=13;
		 marks[2]=1;

//		 System.out.println(marks[0]);
//		 System.out.println(marks[1]);
//		 System.out.println(marks[2]);
		 System.out.println(marks.length);
		 for(int i=0;i<marks.length;i++)
		 {
			 System.out.println(marks[i]);
		 }
		 System.out.println("--------------------------------------");
		 
		 //For-each loop or Modern For loop
		 for(int v:marks) {
			 System.out.println(v);
		 }
		 
		 marks=null;

	}

}
