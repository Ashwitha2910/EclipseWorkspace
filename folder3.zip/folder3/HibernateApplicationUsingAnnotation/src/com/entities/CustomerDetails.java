package com.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity //Class-Level Annotation
@Table(name="CustTable")
public class CustomerDetails {
	@Id           //Member Level
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="cust_id")
	private int cid;
	@Column(name="cust_name")
	private String cname;
	@Column(name="cust_address")
	private String caddress;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCaddress() {
		return caddress;
	}
	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}
	
	
}
