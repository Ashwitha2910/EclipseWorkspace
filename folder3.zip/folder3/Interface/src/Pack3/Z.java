package Pack3;

public class Z implements X,Y {

	@Override
	public void f2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void f1() {
//		System.out.println(X.A);
		
	}

}
