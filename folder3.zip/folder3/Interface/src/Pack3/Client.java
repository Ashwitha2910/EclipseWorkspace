package Pack3;

public class Client {
 public static void main(String[] args) {
	System.out.println(Y.A);
}
}
