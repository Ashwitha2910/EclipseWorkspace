package Pack3;

public interface Y extends X {
	int A=100;
	void f2();
}
