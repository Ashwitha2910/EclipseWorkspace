package Pack3;

public interface X {
	int A=50;
	void f1();
}
