package Pack4;

public class Client {

	public static void main(String[] args) {
		Employee e1=new Employee();
		e1.id=100;
		e1.basic=4000;
		
		Employee e2=new Employee();
		e2.id=100;
		e2.basic=4000;

		System.out.println(e2.compareTo(e1)); 
	}

}