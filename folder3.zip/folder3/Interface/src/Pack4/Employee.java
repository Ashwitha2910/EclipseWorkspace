package Pack4;
//To compare objects implement comparable interface
public class Employee implements Comparable{
	double basic;
	int id;
	
	public double getBasic() {
		return basic;
	}

	public void setBasic(double basic) {
		this.basic = basic;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public int compareTo(Object o) {
		Employee temp=(Employee)o;
		if(this.basic<temp.basic)
			return -1;
		if(this.basic>temp.basic)
			return 1;
		return 0;
	}
	
}
