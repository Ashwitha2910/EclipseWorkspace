package Pack4;

public class Loan implements Comparable {
	double loanAmount;

	@Override
	public int compareTo(Object o) {
		Loan temp=(Loan)o;
		if(this.loanAmount<temp.loanAmount)
			return -1;
		if(this.loanAmount>temp.loanAmount)
			return 1;
		return 0;
	}
}
