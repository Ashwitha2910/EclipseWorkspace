package Pack4;

public class Client2 {
	
		public static void main(String[] args) {
			Loan l1=new Loan();
			l1.loanAmount=10000;
			
			Loan l2=new Loan();
			l2.loanAmount=5000;

			System.out.println(l2.compareTo(l1)); 
		}
	}

