package Pack1;

public interface Shape {
    double pi=3.14;
    void setSize(double size);
    double getArea();
}