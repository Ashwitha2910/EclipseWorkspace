package Pack1;
public class Client2 {

 

    public static void main(String[] args) {
        Shape s;
        s=new Square();
        s.setSize(5.0);
        System.out.println("Area of square:"+s.getArea());

        s=new Circle();
        s.setSize(5.0);
        System.out.println("Area of circle:"+s.getArea());


        /*Circle c=new Circle();
        c.setRadius(5.0);
        System.out.println(c.calculateArea());
        */
    }

 

}