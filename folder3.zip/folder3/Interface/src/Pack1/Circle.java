package Pack1;

 

public class Circle implements Shape {
    double radius;

 

    public double getRadius() {
        return radius;
    }

 

    public void setRadius(double radius) {
        this.radius = radius;
    }

    double calculateArea() {
        return pi*radius*radius;
    }

 

    @Override
    public void setSize(double size) {
        this.setRadius(size);
        // TODO Auto-generated method stub

    }

 

    @Override
    public double getArea() {
        double c=this.calculateArea();
        return c;
    }

 

}