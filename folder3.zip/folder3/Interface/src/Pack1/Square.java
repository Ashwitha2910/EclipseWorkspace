package Pack1;

public class Square implements Shape{
    double size;

 

    public double getSize() {
        return size;
    }

 

    public void setSize(double size) {
        this.size = size;
    }

    double computeArea() {
        return this.size*this.size;
    }

 

    @Override
    public double getArea() {
        double d=this.computeArea();
        return d;
    }

 

}