package com.citius.ui;

import com.citius.bean.Employee;
public class Client2 {
	public static void main(String[] args) {
		Employee e=new Employee();
		e.setId(101);
		e.setName("Dinesh");
		e.setBasicSalary(10000);
		e.setGrade('A');
		
		System.out.println(e.getName());
		System.out.println(e.computeAlloawance());
		System.out.println(e.getDeductions());
		
		Employee e1=new Employee();
		e1.setId(103);
		e1.setName("Shishir");
		e1.setBasicSalary(20000);
		e1.setGrade('A');
		System.out.println(e1.getName());
		System.out.println(e1.computeAlloawance());
		System.out.println(e1.getDeductions());
		
		System.out.println(e1.compareTo(e));
	}
}
