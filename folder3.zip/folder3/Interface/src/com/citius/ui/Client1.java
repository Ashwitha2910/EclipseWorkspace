package com.citius.ui;

import com.citius.bean.AGradeSalaryCalculator;
import com.citius.bean.SalaryCalculator;
public class Client1 {
	public static void main(String[] args) {
		SalaryCalculator c=new AGradeSalaryCalculator ();
		System.out.println(c.computeAllowance(10000.00));
		System.out.println(c.computeDeductions(10000.00));

	}
}
