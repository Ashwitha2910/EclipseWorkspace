package com.citius.bean;

public interface SalaryCalculator {
	double computeAllowance(double basic);
	double computeDeductions(double basic);

}
