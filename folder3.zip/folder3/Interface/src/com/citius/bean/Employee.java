package com.citius.bean;

 

public class Employee implements Comparable {
    private int id;
    private String name;
    private double basicSalary;
    private char grade;
    private SalaryCalculator calculator;

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public double getBasicSalary() {
        return basicSalary;
    }
    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }
    public char getGrade() {
        return grade;
    }
    public void setGrade(char grade) {
        this.grade = grade;
        if(this.grade=='A')
        	calculator=new AGradeSalaryCalculator();
        if(this.grade=='B')
        	calculator=new BGradeSalaryCalculator();
        if(this.grade=='C')
        	calculator=new CGradeCalculator();
    }
    
    	public double computeAlloawance()
    	{
    		return this.calculator.computeAllowance(this.basicSalary);
    	}

    	public double getDeductions()
    	{
    		return this.calculator.computeDeductions(this.basicSalary);
    	}
		@Override
		public int compareTo(Object o) {
			Employee temp=(Employee)o;
//			if(this.id<temp.id)
//				return -1;
//			if(this.id>temp.id)
//				return 1;
//			return 0;
			return temp.name.compareTo(this.name);
			
		}
}