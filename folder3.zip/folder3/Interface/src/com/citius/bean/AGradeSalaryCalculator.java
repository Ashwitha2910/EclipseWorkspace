package com.citius.bean;

public class AGradeSalaryCalculator implements SalaryCalculator{

	@Override
	public double computeAllowance(double basic) {
		return basic*0.45;
	}

	@Override
	public double computeDeductions(double basic) {
		return basic*0.25;
	}

}
