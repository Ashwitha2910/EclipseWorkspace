package com.citius.bean;

public class CGradeCalculator implements SalaryCalculator{

	@Override
	public double computeAllowance(double basic) {
		System.out.println("C -Allowance");
		return 0.28*basic;
	}

	@Override
	public double computeDeductions(double basic) {
		System.out.println("C -Deduction");
		return 0.10*basic;
	}

}
