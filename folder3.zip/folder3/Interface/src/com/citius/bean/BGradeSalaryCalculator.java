package com.citius.bean;

public class BGradeSalaryCalculator implements SalaryCalculator{

	@Override
	public double computeAllowance(double basic) {
		
		return basic*0.33;
	}

	@Override
	public double computeDeductions(double basic) {
		return basic*0.20;
	}

}
