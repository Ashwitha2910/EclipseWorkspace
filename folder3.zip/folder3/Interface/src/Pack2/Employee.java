package Pack2;

public class Employee {
	int id;
}
