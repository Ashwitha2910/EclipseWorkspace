package Pack2;

public interface Y {
	void f2();
}
