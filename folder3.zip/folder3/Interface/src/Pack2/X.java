package Pack2;

public interface X {
	void f1();

}
