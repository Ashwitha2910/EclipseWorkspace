package com.entities;



import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class MainClass {

	public static void main(String[] args) {
		Session s=new Configuration().configure().buildSessionFactory().openSession();
		Transaction t= s.beginTransaction();
//		City city=new City();
//		Country cnt=new Country();
//		List<City> list=new ArrayList<City>();
//		
//		cnt.setCnt_id(91);
//		cnt.setCnt_name("India");
//		
//		city.setCity_id(001);
//		city.setCity_name("Mangalore");
//		city.setCountry(cnt);
//		City city1=new City();
//		city1.setCity_id(002);
//		city1.setCity_name("Mumbai");
//		city1.setCountry(cnt);
//		
//		list.add(city);
//		list.add(city1);
//		cnt.setList(list);
//		
//		s.save(city);
//		s.save(city1);
//		s.save(cnt);
//		t.commit();
//		
//		City getCity=s.load(City.class, new Integer(1));
//		System.out.println("City id: "+getCity.getCity_id());
//		System.out.println("City name: "+getCity.getCity_name());
		
		Criteria crt=s.createCriteria(City.class);
		List<City> cityList=crt.list();
		crt.add(Restrictions.eq("city_name", "Mumbai"));
		for(City c:cityList)
		{
			
			System.out.println(c.getCity_name());
		}
				
		t.commit();
		s.close();
	}

}
