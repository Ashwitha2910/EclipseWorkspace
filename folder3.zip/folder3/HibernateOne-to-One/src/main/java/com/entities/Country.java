package com.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Country")
public class Country {
	@Id
	@Column(name="Cnt_id")
	private int cnt_id;
	@Column(name="Cnt_name")
	private String cnt_name;
	
	public int getCnt_id() {
		return cnt_id;
	}
	public void setCnt_id(int cnt_id) {
		this.cnt_id = cnt_id;
	}
	public String getCnt_name() {
		return cnt_name;
	}
	public void setCnt_name(String cnt_name) {
		this.cnt_name = cnt_name;
	}
	
	
}
