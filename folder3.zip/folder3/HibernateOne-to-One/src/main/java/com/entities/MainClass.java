package com.entities;



import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainClass {

	public static void main(String[] args) {
		Session s=new Configuration().configure().buildSessionFactory().openSession();
		Transaction t= s.beginTransaction();
		City city=new City();
		Country cnt=new Country();
		
		
		
		cnt.setCnt_id(91);
		cnt.setCnt_name("India");
		
		city.setCity_id(001);
		city.setCity_name("Mumbai");
		city.setCountry(cnt);
		
		s.save(city);
		s.save(cnt);
		t.commit();

	}

}
