package com.citius.bean;

public class Client {

	public static void main(String[] args) {

		Circle c=new Circle();
		c.radius=10;
		Circle c1=new Circle();
		c1.radius=5;
		System.out.println(c);
		System.out.println(c1);
	}

}
