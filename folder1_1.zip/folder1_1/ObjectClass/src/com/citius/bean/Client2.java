package com.citius.bean;

public class Client2 {

	public static void main(String[] args) {
		int a,b;
		a=100;
		b=100;
		
		System.out.println(a==b);
		
		Circle c1=new Circle();
		c1.radius=10;
		
		Circle c2=new Circle();
		c2.radius=10;
		
		System.out.println(c1==c2); //Object addresses are compared
		System.out.println(c1.equals(c2));

	}

}
