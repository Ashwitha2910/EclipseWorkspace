package com.citius.bean;

public class Client3 {

	public static void main(String[] args) {
		Circle c=new Circle();  //Object reference
		//upcasting:implicit typecasting
		c.radius=67;
		

	}

}
