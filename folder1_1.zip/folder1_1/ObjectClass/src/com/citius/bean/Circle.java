package com.citius.bean;

import java.util.Objects;

public class Circle {
	int radius;
	
	public double computeArea()
	{
		returnn 3.14*this.radius*this.radius;
	}

	@Override
	public String toString() {
		return "Circle [radius=" + radius + "]";
	}
//	@Override
//	public String toString()
//	{
//		return "Circle["+"radius="+this.radius+"]";
//	}
//
//	public boolean equals(Object obj)
//	{
//		Circle temp=(Circle)obj;
//		if(this.radius==temp.radius)
//			return true;
//		else
//			return false;
//	}

	@Override
	public int hashCode() {
		return Objects.hash(radius);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Circle other = (Circle) obj;
		return radius == other.radius;
	}
}
