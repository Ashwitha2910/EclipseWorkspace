package demo4;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("demo4/bean.xml");
		EmployeeRepo empRepo = context.getBean(EmployeeRepo.class);
		empRepo.insert(new Employee(1, "John"));
		empRepo.insert(new Employee(2, "Simon"));
		System.out.println("Employee Inserted");

		Employee employee = empRepo.getEmployeeById(2);
		System.out.println(employee);
		
		Employee em =empRepo.deleteEmployee(1);
		System.out.println(em);
		

	}

}
