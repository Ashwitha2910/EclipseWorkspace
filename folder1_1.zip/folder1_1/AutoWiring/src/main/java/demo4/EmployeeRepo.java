package demo4;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public class EmployeeRepo implements EmpRepo<Employee>{

private Map<Integer,Employee> reporitory;
	
	public EmployeeRepo() {
		this.reporitory=new HashMap<Integer, Employee>();
	}

	public void insert(Employee t) {
		reporitory.put(t.getEmp_id(), t);
		
	}

	public Employee getEmployeeById(int id) {
		return reporitory.get(id);
	}

	public Employee deleteEmployee(int id) {
		return reporitory.remove(id);
	}


}
