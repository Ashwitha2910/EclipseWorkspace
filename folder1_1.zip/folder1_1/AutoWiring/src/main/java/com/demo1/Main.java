package com.demo1;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("com/demo1/bean.xml");
		Employee e=context.getBean("emp",Employee.class);
		System.out.println(e.getAddress());
		

	}

}
