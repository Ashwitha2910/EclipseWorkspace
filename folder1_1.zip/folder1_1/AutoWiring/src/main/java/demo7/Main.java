package demo7;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class Main {

	public static void main(String[] args) {
		AbstractApplicationContext context=new AnnotationConfigApplicationContext(javaConfiguration.class);
		Product p=context.getBean("product",Product.class);
		System.out.println(p.getProd_id());
		System.out.println(p.getProd_name());
		System.out.println(p.getP_desc().getProd_brand());

	}

}
