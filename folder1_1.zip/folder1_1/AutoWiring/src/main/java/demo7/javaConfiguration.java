package demo7;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
//@ComponentScan(basePackages = "demo6")
public class javaConfiguration {
	
	@Bean
	public Product getProduct() {
		Product product=new Product();
		product.setP_desc(getDesc());
		return product;
	}
	
	@Bean
	public ProductDescription getDesc() {
		ProductDescription desc=new ProductDescription();
		return desc;
	}
}
