package demo3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("demo3/bean.xml");
		LoginService s=context.getBean("loginService",LoginService.class);
		System.out.println(s.isValidUser());

	}

}
