package demo3;

import org.springframework.stereotype.Service;

@Service
public class LoginService {
	public boolean isValidUser()
	{
		if("admin".equals("admin"))
		{
			return true;
		}
		else
			return false;
	}
}
