package demo5;

public class PaymentServiceImpl{
	//join-point--before
	public void paymentService() {
		System.out.println("Payment Started....");
		
		System.out.println("Payment done....");
		
	}
	//join-point--after

}
