package demo5;

public interface PaymentService {
	
	public void paymentService();
}
