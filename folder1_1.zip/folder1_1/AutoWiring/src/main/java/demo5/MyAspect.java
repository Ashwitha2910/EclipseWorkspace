package demo5;

import java.util.Scanner;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class MyAspect {
	Scanner input=new Scanner(System.in);
	
	@Before("execution(* demo5.PaymentServiceImpl.paymentService())")
	public void printBefore() {
		System.out.println("Enter Username: ");
		String un=input.next();
		System.out.println("Enter Password: ");
		String pw=input.next();
		if(un.equals("admin")&&pw.equals("admin"))
			System.out.println("Valid User");
		else
			System.out.println("Invalid User");
	
	}
	@After("execution(* demo5.PaymentServiceImpl.paymentService())")
	public void printAfter() {
		System.out.println("Transaction done successfully...");
	}
}
