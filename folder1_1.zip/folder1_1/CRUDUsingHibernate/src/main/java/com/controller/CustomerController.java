package com.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.dao.CustomerDao;
import com.entities.Customer;

public class CustomerController {
	//we will create all crud methods
	static Configuration conf=CustomerDao.getCustomerObject();
	static Customer cust=new Customer();
	
	//add customer
	public static void addCustomer()
	{
		SessionFactory sf=conf.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter your name: ");
		String cust_name=input.next();
		
		System.out.println("Enter your address: ");
		String cust_address=input.next();
		
		cust.setCust_name(cust_name);
		cust.setCust_address(cust_address);
		s.save(cust);
		t.commit();
		System.out.println("Customer Added successfully..");
	}
	
	public static void updateCustomer()
	{
		SessionFactory sf=conf.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Id to update Customer details: ");
		int cust_id=input.nextInt();
		
		
		System.out.println("Enter your new name: ");
		String cust_name=input.next();
		
		//update Customer set cust_name=:n where cust_id=:i
		Query q=s.createQuery("update Customer set cust_name=:n where cust_id=:i");
		q.setParameter("i", cust_id);
		q.setParameter("n", cust_name);
		int status=q.executeUpdate();
		System.out.println(status+" rows updated");
		t.commit();
		
	}
	
	public static void deleteCustomer()
	{

		SessionFactory sf=conf.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Id to delete record: ");
		int cust_id=input.nextInt();
		
		Query q=s.createQuery("delete from Customer where cust_id=:i");
		q.setParameter("i", cust_id);
		int status=q.executeUpdate();
		System.out.println(status+" Rows deleted");
		t.commit();
	}
	
	public static void displayCustomers()
	{
		SessionFactory sf=conf.buildSessionFactory();
		Session s=sf.openSession();
		TypedQuery query=s.createQuery("from Customer");
		List<Customer> list=query.getResultList();
		Iterator<Customer> itr=list.iterator();
		while(itr.hasNext())
		{
			Customer cst=itr.next();
			System.out.println("Name= "+cst.getCust_name()+" -- Address= "+cst.getCust_address());
			
		}
	}
	public static void searchCustomer()
	{
		SessionFactory sf=conf.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Id to search Customer: ");
		int cust_id=input.nextInt();
		
//		TypedQuery q=s.createQuery("from Customer where cust_id=:i");
//		q.setParameter("i", cust_id);
//		List<Customer> l=q.getResultList();
//		int status=q.executeUpdate();
//		if(status>0) {
//		System.out.println("Customer found");
////		System.out.println("Name: "+cust_id+"-- Customer Name: ");
//		}
//		Iterator<Customer> itr=l.iterator();
		
		Customer getCust=s.get(Customer.class, new Integer(cust_id));
		System.out.println("Customer id: "+getCust.getCust_id());
		System.out.println("Customer name: "+getCust.getCust_name());
		System.out.println("Customer id: "+getCust.getCust_address());
		t.commit();
	}
}
