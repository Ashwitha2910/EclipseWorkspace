package com.view;

import com.controller.CustomerController;

public class MainClas {

	public static void main(String[] args) {
		CustomerController controller= new CustomerController();
//		controller.addCustomer();
//		controller.updateCustomer();
//		controller.deleteCustomer();
		controller.searchCustomer();
//		controller.displayCustomers();

	}

}
