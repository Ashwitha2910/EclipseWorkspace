package com.citius.bean;

public class NumberClient {

	public static void main(String[] args) {
		NumberAnalyzer n1=new NumberAnalyzer(8,3,5);
		NumberAnalyzer n2=new NumberAnalyzer(1,9,5);
		
		
		System.out.println("The largest number is "+n1.getLargest());
		System.out.println("The smallest number is "+n1.getSmallest());
		System.out.println(n1);

		System.out.println("The largest number is "+n2.getLargest());
		System.out.println("The smallest number is "+n2.getSmallest());
		System.out.println(n1);
		
		System.out.println(n1==n2);
		System.out.println(n1.equals(n2));
	}

}
