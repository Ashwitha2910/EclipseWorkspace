package com.citius.bean;

import java.util.Arrays;

public class ArrayAnalyzer {
	 int[] arr;
	
	
	public int[] getArr() {
		return arr;
	}
	public void setArr(int[] arr) {
		this.arr = arr;
	}
	public ArrayAnalyzer(int[]arr)
	{
		this.arr=arr;
	}
	public long sum()
	{
		int sum=0;
		for(int v:arr)
		{
			sum+=v;
			
		}
		return sum;
	}
	public int getBiggest()
	{
		int s=arr[0];
		for(int a:arr)
		{
			if(a>s)
			{
				s=a;
			}
		}
		return s;
			
	}
	
	public int getSmallest()
	{
		int s=arr[0];
		for(int a:arr)
		{
			if(a<s)
			{
				s=a;
			}
		}
		return s;
			
	}
	@Override
	public String toString() {
		return "ArrayAnalyzer [arr=" + Arrays.toString(arr) + ", getArr()=" + Arrays.toString(getArr()) + ", sum()="
				+ sum() + ", getBiggest()=" + getBiggest() + ", getSmallest()=" + getSmallest() + "]";
	}
	
	
}
