package com.citius.bean;

import java.util.Objects;

public class Loan {
	private double loanAmount;
	private int tenure;
	
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	@Override
	public String toString() {
		return "Loan [loanAmount=" + loanAmount + ", tenure=" + tenure + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(loanAmount, tenure);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Loan other = (Loan) obj;
		return Double.doubleToLongBits(loanAmount) == Double.doubleToLongBits(other.loanAmount)
				&& tenure == other.tenure;
	}
	
	
	
	
}
