package com.citius.bean;

import java.util.Objects;

public class NumberAnalyzer {
	private int num1,num2,num3;

	public NumberAnalyzer(int num1, int num2, int num3) {
		super();
		this.num1 = num1;
		this.num2 = num2;
		this.num3 = num3;
	}
	
	public int getLargest()
	{
		if(num1>num2 &&num1>num3)
			return this.num1;
		else if (num2>num3)
			return this.num2;
		else
			return this.num3;
	}
	public int getSmallest()
	{
		if(num1<num2 &&num1<num3)
			return this.num1;
		else if (num2<num3)
			return this.num2;
		else
			return this.num3;
	}

	@Override
	public String toString() {
		return "NumberAnalyzer [num1=" + num1 + ", num2=" + num2 + ", num3=" + num3 + ", getLargest()=" + getLargest()
				+ ", getSmallest()=" + getSmallest() + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(num1, num2, num3);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NumberAnalyzer other = (NumberAnalyzer) obj;
		return num1 == other.num1 && num2 == other.num2 && num3 == other.num3;
	}
	
	
}
