package com.citius.bean;

public class ArrayClient {

	public static void main(String[] args) {
		int[] a= {2,3,4,5,6};
		ArrayAnalyzer a1=new ArrayAnalyzer(a);
		
		System.out.println("The sum of the array element is "+a1.sum());
		System.out.println("The biggest of the array element is "+a1.getBiggest());
		System.out.println("The smallest of the array element is "+a1.getSmallest());

		System.out.println(a1);
	}

}
