package com.citius.bean;

public class LoanClient {

	public static void main(String[] args) {
		Loan loan1=new Loan();
		loan1.setLoanAmount(24000.00);
		loan1.setTenure(12);
		
		Loan loan2=new Loan();
		loan2.setLoanAmount(24000.00);
		loan2.setTenure(12);
		
		Loan loan3=new Loan();
		loan3.setLoanAmount(24000.00);
		loan3.setTenure(16);
		
		
		
		System.out.println(loan1);
		System.out.println(loan2==loan3);
		System.out.println(loan2.equals(loan3));
		
		//data in the object should be printed
	}
	

}
