
public class StringBufferClient {

 

    public static void main(String[] args) {
        StringBuffer buffer=new StringBuffer(" Tech Village");
        buffer.insert(0, "Embassy");
        System.out.println(buffer);

        System.out.println(buffer.append(",Bangalore "));
        System.out.println(buffer);

        System.out.println(buffer.append(",Bangalore, "));
        System.out.println(buffer);

        System.out.println(buffer.append(500012));
        System.out.println(buffer);
        
//        System.out.println(buffer.reverse());
        System.out.println(buffer.substring(10,15));
        
        String myStr=buffer.toString();
        System.out.println(myStr);

        //System.out.println(buffer.delete(0, 3));
        //System.out.println(buffer.deleteCharAt(6));

 

    }

 

}
