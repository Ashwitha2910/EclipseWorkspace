
public class StringClient {

	public static void main(String[] args) {
		String s1=new String("Embassy Tech Village");
		System.out.println(s1.length());
		System.out.println(s1.charAt(0));
		System.out.println(s1.charAt(s1.length()-1));
		System.out.println(s1.indexOf('x'));
		System.out.println(s1.indexOf('e'));
		System.out.println(s1.indexOf('e',10));
		System.out.println(s1.lastIndexOf('a'));
		System.out.println(s1.indexOf('a',10));
		
		String s2=s1.toUpperCase();
		System.out.println(s2);
		
		String s3=s1.toLowerCase();
		System.out.println(s3);
		
		System.out.println(s1.startsWith("Emb"));
		System.out.println(s1.endsWith("Village"));
		System.out.println(s1.isEmpty());
		System.out.println(s1.contains("Tech"));
		
		String s4=new String("Bangalore");
		System.out.println(s1.equals(s4));
		
		String s5=new String("bangalore");
		System.out.println(s4.equals(s5));
		System.out.println(s4.equalsIgnoreCase(s5));
		
		String s6="city";
		
		String s7="textile";
		String s8=new String("textile");
		System.out.println(s7.equals(s8));
		System.out.println(s7==s8);
		String s9="city";
		System.out.println(s6.equals(s9));

		String s10=new String("embassy");
		String s11=new String("Embassy");
		System.out.println(s11.compareTo(s10));

		
	}

}
