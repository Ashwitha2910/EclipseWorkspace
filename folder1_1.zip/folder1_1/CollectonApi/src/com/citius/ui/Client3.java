package com.citius.ui;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Client3 {
	public static void main(String[] args) {
		String s1="Country Name";
		String s2="Independence Year";
		String s3="Prime Minister";
		
		String s4="India";
		String s5="1947";
		String s6="Modi";
		
		Map<String,String> map=new HashMap<>();
		map.put(s1, s4);
		map.put(s2,s5);
		map.put(s3,s6);
		System.out.println(map);

		System.out.println(map.get("Country Name"));
		System.out.println(map.get("Prseident"));
		
		Set<String> allKeys=map.keySet();
		for(String k:allKeys)
		{
			System.out.println(map.get(k));
		}
		
		Collection<String> allVals=map.values();
		for(String v:allVals)
		{
			System.out.println(v);
		}
		Map <String, Student> studentMap;
		studentMap=new TreeMap<>();
		studentMap.put("BEST", new Student("Victor",99,100));
		studentMap.put("Good", new Student("Nalini",81,79));
		studentMap.put("Average", new Student("John",46,60));
		System.out.println(studentMap);
		
		Set<String> a=studentMap.keySet();
		for(String k:a) {
			System.out.println(k);
		}
		

	}
}
