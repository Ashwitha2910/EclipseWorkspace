package com.citius.ui;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.citius.bean.Sale;
public class Client4 {
	public static void main(String[] args) {
		Sale s1=new Sale("Bangalore","Jan",12000.00);
		Sale s2=new Sale("Mumbai","Mar",4000.00);
		Sale s3=new Sale("Bangalore","Oct",8000.00);
		Sale s4=new Sale("Delhi","Aug",16000.00);
		Sale s5=new Sale("Mumbai","Dec",22000.00);
		Sale s6=new Sale("Delhi","Jan",36000.00);
		Sale s7=new Sale("Bangalore","Apr",10000.00);
		Sale s8=new Sale("Delhi","Aug",8000.00);
		
		List<Sale> sd=new ArrayList<Sale>();
		sd.add(s1); sd.add(s2);
		sd.add(s3); sd.add(s4);
		sd.add(s5); sd.add(s6);
		sd.add(s7); sd.add(s8);
		System.out.println(sd);

		Map<String,Double> citywise=new TreeMap<>();
		
		for(Sale s:sd)
		{
			if(citywise.get(s.getCityName())==null)
			{
				citywise.put(s.getCityName(), s.getSaleAmount());
			}
			else
				citywise.put(s.getCityName(), citywise.get(s.getCityName())+s.getSaleAmount());
			
		}
			System.out.println(citywise);
		
			Map<String,Double> monthwise=new TreeMap<>();
			
			for(Sale m:sd)
			{
				if(monthwise.get(m.getMonth())==null)
				{
					monthwise.put(m.getMonth(), m.getSaleAmount());
				}
				else
					monthwise.put(m.getMonth(), monthwise.get(m.getMonth())+m.getSaleAmount());
				
			}
			System.out.println(monthwise);

	}
}
