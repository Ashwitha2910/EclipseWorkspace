package com.citius.ui;

import java.util.Objects;

public class Student {
	String name;
	int mark1,mark2;
	public Student(String name, int mark1, int mark2) {
		super();
		this.name = name;
		this.mark1 = mark1;
		this.mark2 = mark2;
	}
	
	public int getTotal()
	{
		return mark1+mark2;
	}

	

	@Override
	public String toString() {
		return "Student [name=" + name + ", mark1=" + mark1 + ", mark2=" + mark2 + ", getTotal()=" + getTotal()
				+ ", hashCode()=" + hashCode() + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Objects.equals(name, other.name);
	}

	
	}


	
	
	

