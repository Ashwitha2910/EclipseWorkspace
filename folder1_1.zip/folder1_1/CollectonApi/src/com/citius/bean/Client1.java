package com.citius.bean;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.citius.ui.Student;

public class Client1 {

	public static void main(String[] args) {
		Integer i1=new Integer(300);
		Integer i2=new Integer(40);
		Integer i3=new Integer(200);
		Integer i4=107;
		
		List<Integer> mylist=new ArrayList<>();
		mylist.add(i1);
		mylist.add(i2);
		mylist.add(i3);
		mylist.add(i4);
		mylist.add(new Integer(250));
		mylist.add(300);
		
		System.out.println(mylist);
		System.out.println(mylist.isEmpty());
		System.out.println(mylist.contains(250));
		System.out.println(mylist.contains(1000));
		
		mylist.remove(new Integer(250));
		System.out.println(mylist);
		
		System.out.println(mylist.indexOf(new Integer(300)));
		
		System.out.println(mylist.get(2));
		mylist.set(2, 400);
		System.out.println(mylist);
		
		mylist.clear();
		System.out.println(mylist.isEmpty());
		
		for(Integer i:mylist) {
			System.out.println(i.doubleValue());
		}
		
		Iterator<Integer> it1=mylist.iterator();
		while(it1.hasNext()) {
			Integer i=it1.next();
			System.out.println(i.floatValue());
		}
		
		List<String> strList=new ArrayList<>();
		String s1=new String("Ashwitha");
		String s2=new String("Prajna");
		String s3=new String("Shishir");
		String s4="Sharanya";
		
		strList.add(s1);
		strList.add(s2);
		strList.add(s3);
		strList.add(s4);
//		strlist.add(new Integer(250));
		strList.add("Suksham");

		System.out.println(strList);
		System.out.println(strList.isEmpty());
		System.out.println(strList.contains("Divya"));
		System.out.println(strList.contains("Suksham"));
		
		for(String i:strList)
		{
			System.out.println(i.length());
		}
		Iterator<String> it2=strList.iterator();
		while(it2.hasNext()) {
			String i=it2.next();
			System.out.println(i.length());
		}
		
		List<Student> stdList=new ArrayList<>();
		stdList.add(new Student("Ram",70,80));
		stdList.add(new Student("Seeta",68,86));
		stdList.add(new Student("Lakshman",98,84));
		
		System.out.println(stdList);
		System.out.println(stdList.contains("Seeta"));
		System.out.println(stdList.equals(strList));
		System.out.println(stdList.get(2));
		
		List list=new ArrayList();
		list.add(400);
		list.add("Hello");
		list.add(new Student("Deepthi",30,40));
		list.add(new Double(90.00));
		
		System.out.println(list);
		
		for(Object o:list)
		{
			if(o instanceof Integer)
			{
				Integer temp=(Integer)o;
				System.out.println(temp.intValue());
			}
			if(o instanceof String)
			{
				String temp=(String)o;
				System.out.println(temp.length());
			}
			if(o instanceof Student)
			{
				Student temp=(Student)o;
				System.out.println(temp.getTotal());
			}
			if(o instanceof Double)
			{
				Double temp=(Double)o;
				System.out.println(temp.intValue());
			}
		}
		list.clear();
		System.out.println(list.isEmpty());
	}
	


}
