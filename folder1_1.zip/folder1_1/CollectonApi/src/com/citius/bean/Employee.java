package com.citius.bean;

import java.util.Objects;

public class Employee implements Comparable<Employee> {
	int id;
	String name;
	char grade;
	double basicSalary;
	int age;
	
	public Employee(int id, String name, char grade, double basicSalary, int age) {
		super();
		this.id = id;
		this.name = name;
		this.grade = grade;
		this.basicSalary = basicSalary;
		this.age = age;
	}
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", grade=" + grade + ", basicSalary=" + basicSalary + ", age="
				+ age + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(age, basicSalary, grade, id, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return age == other.age && Double.doubleToLongBits(basicSalary) == Double.doubleToLongBits(other.basicSalary)
				&& grade == other.grade && id == other.id && Objects.equals(name, other.name);
	}

	@Override
	public int compareTo(Employee o) {
		if(this.basicSalary<o.basicSalary)
			return -1;
		if(this.basicSalary>o.basicSalary)
			return 1;
		return 0;
		
	}
	
	public double sum()
	{
		double sum=0.0;
		for(Employee e:Employee)
		{
			sum+=e.basicSalary;
		}
	}

	
	
	
}
