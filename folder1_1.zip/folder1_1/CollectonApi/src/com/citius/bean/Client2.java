package com.citius.bean;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import com.citius.ui.Student;

public class Client2 {

	public static void main(String[] args) {
		Set<String> myset1=new TreeSet<>();
		myset1.add("Embassy");
		myset1.add("Bangalore");
		myset1.add("Tech");
		myset1.add("Village");
		myset1.add("JDBC");
//		myset1.add("Embassy");
		
		System.out.println(myset1);
		
		System.out.println(myset1.contains("Tech"));
		System.out.println(myset1.remove("Tech"));
		System.out.println(myset1.size());
		System.out.println(myset1);

		//System.out.println(myset1.isEmpty());
		//myset1.clear();
		//System.out.println(myset1.isEmpty());
		
		for (String s:myset1)
		{
			System.out.println(s+":"+s.length());
		}
		
		Iterator<String> it1=myset1.iterator();
		while(it1.hasNext()) {
			String s=it1.next();
			System.out.println(s+":"+s.length());
		}
//-------------------------------------------------------------------------
		
		Set<Double> myset2=new TreeSet<>();
		myset2.add(10.00);
		myset2.add(20.00);
		myset2.add(30.00);
		myset2.add(40.00);
		myset2.add(50.00);
		
		System.out.println(myset2);

		System.out.println(myset2.contains(40.00));
		System.out.println(myset2.size());

		myset2.remove(40.00);
		System.out.println(myset2.size());
		System.out.println(myset2);
//
//		System.out.println(myset2.isEmpty());
//		myset2.clear();
//		System.out.println(myset2.isEmpty());
		
		Iterator<Double> it2=myset2.iterator();
		while(it2.hasNext()) {
			Double s1=it2.next();
			System.out.println(s1+":"+s1.intValue());
		}
		
		//-----------------------------------------------------------------------
		AgeComparator a1=new AgeComparator();
		AageDesc d1=new AageDesc();
		GradeComparator g1=new GradeComparator();
		Set<Employee> ms3=new TreeSet<>(g1);
		
		Employee e1=new Employee(104,"Ashwitha",'C',1200.00,22);
		Employee e2=new Employee(109,"Paras",'A',2400.00,24);
		Employee e3=new Employee(106,"Rishikesh",'B',3000.00,20);
		Employee e4=new Employee(107,"Anurag",'D',1000.00,25);
		
		ms3.add(e1);
		ms3.add(e2);
		ms3.add(e3);
		ms3.add(e4);
		
		System.out.println(ms3);
		Employee dummy=new Employee(105,"Paras",'B',2400.00,24);
		System.out.println(ms3.contains(dummy));
		//-------------------------------------------------------------------
		TotalAscComparator asc=new TotalAscComparator();
		TotalDescComparator dcs=new TotalDescComparator();
		Set<Student> st=new TreeSet<>(dcs);
		
		st.add(new Student("Vincent",80,68));
		st.add(new Student("Harry",77,65));
		st.add(new Student("Nikhil",86,68));
		st.add(new Student("Joanna",77,88));

		System.out.println(st);

	}

}
