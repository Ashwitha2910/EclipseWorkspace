package com.citius.bean;

public class Sale {
	private String cityName;
	private String month;
	private double saleAmount;
	
	public Sale(String cityName, String month, double saleAmount) {
		super();
		this.cityName = cityName;
		this.month = month;
		this.saleAmount = saleAmount;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public double getSaleAmount() {
		return saleAmount;
	}

	public void setSaleAmount(double saleAmount) {
		this.saleAmount = saleAmount;
	}

	@Override
	public String toString() {
		return "\n Sale [cityName=" + cityName + ", month=" + month + ", saleAmount=" + saleAmount + "]";
	}
	
	public int totalSaleAmount()
	{
		
	}
	
	
}
