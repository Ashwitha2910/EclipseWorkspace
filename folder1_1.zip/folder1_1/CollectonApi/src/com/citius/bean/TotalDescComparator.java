package com.citius.bean;
import java.util.Comparator;

import com.citius.ui.*;
public class TotalDescComparator implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		return o2.getTotal()-o1.getTotal();

	}

}
