
public class A {
//	void f1(short a)
//	{
//		System.out.println("f1 with short "+a);
//	}
	static void f1(double a)
	{
		System.out.println("f1 with double "+a);
	}
//	void f1(int a)
//	{
//		System.out.println("f1 with int "+a);
//	}
//	void f1(char a)
//	{
//		System.out.println("f1 with char "+a);
//	}
	static void f1(int... marks)
	{
		System.out.println("f1 with array ");
		System.out.print("[");
		for(int a:marks)
		{
			System.out.print(a);
			System.out.print(",");
		}
		System.out.print("]");

	}
//	void f1(int[] marks)
//	{
//		System.out.println("f1 with array ");
//		System.out.print("[");
//		for(int a:marks)
//		{
//			System.out.print(a);
//			System.out.print(",");
//		}
//		System.out.print("]");
//
//	}
}
