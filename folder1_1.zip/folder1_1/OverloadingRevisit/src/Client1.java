
public class Client1 {
	
	static void test1(Rectangle r)
	{
		System.out.println("Rreceiving a Rectangle and Changing ");
		r.length=9000;
		r.width=800;
		System.out.println("After Changing "+r.length+","+r.width);
	}
	
	static void test1(int[] arr)
	{
		System.out.println("Receiving and changing");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=20;
			System.out.print("After changing ");
			for(int a:arr)
				System.out.print(a+",");
			System.out.println("]");
		}
	}
	
	static void test1(int a)
	{
		System.out.println("Rceiving "+a+" and increamenting");
		a++;
		System.out.println("Value changed to "+a);
	}

	public static void main(String[] args) {
		int a=100;
		System.out.println("Before invoke :");
		System.out.println(a);
		test1(a);
		System.out.println("After invoke :");
		System.out.println(a);
		
		int[] prices= {100,200,300};
		System.out.print("Before invoke [");
		for(int p:prices)
			System.out.print(p+",");
		System.out.print("]");
		test1(prices);
		System.out.print("After invoke [");
		for(int p:prices)
			System.out.print(p+",");
		System.out.print("]");
		
		Rectangle obj=new Rectangle();
		obj.length=100;
		obj.width=200;
		System.out.println("\n");
		System.out.print("In main ");
		System.out.println("["+obj.length+","+obj.width+"]");
		test1(obj);
		System.out.println("["+obj.length+","+obj.width+"]");

	}

}
