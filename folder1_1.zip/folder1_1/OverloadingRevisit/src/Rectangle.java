
public class Rectangle {
	int width,length;
}
