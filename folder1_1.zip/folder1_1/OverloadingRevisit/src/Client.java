
public class Client {

	public static void main(String[] args) {
		A obj=new A();
		int x=100;
		A.f1(x);
		
		A.f1(200);
		
		short y=250;
		A.f1(y);
		
		A.f1('A');
		
		int[] arr= {1,2,3};
		obj.f1(arr);
		
		int[] arr1= {2,4,6,8,12,14,16,18,20};
		obj.f1(arr1);
		
		int[] arr2= {};
		obj.f1(arr2);
		
		obj.f1(100,200,300,4000);//it will give error
	}

}
