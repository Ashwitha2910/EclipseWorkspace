import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Greet {
	public static void main(String[] args) {
//		System.out.println("Namaste");
//		int age=24;
//		System.out.println(++age);
//		System.out.println(50);
//		System.out.println("Enter your name:");
//		Scanner sc =new Scanner(System.in);
//		String a=sc.next();
//		System.out.println(a);
//		
//		List<String> li=new ArrayList();
//		li.add("ash");
//		li.add("akhil");
//		System.out.println(li);
		
		Scanner sc = new Scanner(System.in);

		int number =(int)(Math.random()*100);
		 int number1 = 0;
		do{
		 System.out.println("Enter the Number");
		 number1 = sc.nextInt();

		if (number1 == number)
		{
		System.out.println("Correct Number");
		break;
		}
		else if ( number1> number)
		{
		 System.out.println("Your number is Greater");
		}
		 else
		{
		System.out.println("Your Number is Lesser");
		}

  }
		while(number1 >= 0);



		 System.out.println("Your number...");
		 System.out.println(number);
	}

}
