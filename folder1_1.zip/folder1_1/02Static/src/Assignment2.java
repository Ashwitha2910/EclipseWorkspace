
public class Assignment2 {
	 int[] arr;
	    int front=0;
	    int rear=0;
	    
	    public Assignment2() {
	        arr=new int[10];
	        System.out.println("Queue with 10 elements created");
	    }
	    
	    public Assignment2(int size) {
	        arr=new int[size];
	        System.out.println("Queue with " +size+ " elements created");
	    }
	    
	    void add(int n) {
	        arr[rear]=n;
	        rear++;
	        front++;
	        
	    }
	    
	    int remove() {
	        arr[front]=arr[front+1];
	        return arr[front];
	    }
	    
	    void print() {
	        System.out.print("[");
	        for(int i=0;i<front;i++)
	        {
	        	System.out.print(arr[i]+",");
	        }
	        System.out.println("]");
	    }
}
