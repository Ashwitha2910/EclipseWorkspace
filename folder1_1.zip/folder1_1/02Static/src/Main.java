
public class Main {

	public static void main(String[] args) {
		A.print();
		
		A obj1=new A();
		obj1.print(); //not the correct way
		
		A obj2=new A();
		obj2.print();

	}

}
