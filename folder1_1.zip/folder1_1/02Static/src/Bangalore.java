
public class Bangalore {
	int i,j;
	 
	Bangalore()
	{
		System.out.println("Welcome to Bangalore");
	}

	
	Bangalore(int i,int j)
	{
		this.i=i;
		this.j=j;
	}
	void print()
	{
		System.out.println(i*j);
	}
}
