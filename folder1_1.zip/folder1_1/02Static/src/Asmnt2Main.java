
public class Asmnt2Main {

	public static void main(String[] args) {
		Assignment2 a1=new Assignment2();
		a1.add(2);
		a1.add(4);
		a1.add(6);
		a1.print();
		
	a1.remove();
	a1.print();
	}

}
