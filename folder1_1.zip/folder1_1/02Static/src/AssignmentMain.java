
public class AssignmentMain {
	public static void main(String[] args) {
		Assignment1 a1=new Assignment1();
		Assignment1 a2=new Assignment1(2,4);
		
		a1.print(2);
		a2.printmul(3,5);	
	}
	
			
}
