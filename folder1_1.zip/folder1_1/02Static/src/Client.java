
public class Client {

	public static void main(String[] args) {
		Bangalore b1,b2;
		b1=new Bangalore(6,7);
		b2=new Bangalore();
		
//		b1.i=10;
//		b1.j=20;
		b1.print();

		b2.i=1000;
		b2.j=20;
		b2.print();
	}

}
