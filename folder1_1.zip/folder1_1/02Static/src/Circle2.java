public class Circle2 {
    private int radius;  //Instance variable
    static double pi=3.14;
    
    void setRadius(int radius)
    {
    	this.radius=radius;
    }
    int getRadius()
    {
    	return radius;
    }
    
    double computeArea() {
        double area;
        area=pi*radius*radius;
        return area;
    }
}
