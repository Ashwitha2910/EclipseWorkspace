
public class CircleClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle2 c1;
		c1=new Circle2();
		c1.setRadius(10);
		System.out.println(c1.computeArea());
		
		c1.setRadius(15);
		System.out.println(c1.computeArea());

		Circle2 c2;
		c2=new Circle2();
		c2.setRadius(20);
		System.out.println(c2.computeArea());
		
		Circle2 c3=new Circle2();
		c3.setRadius(16);
		System.out.println(c3.computeArea());
		System.out.println("----------------------------------------------");
		
		System.out.println(c1.pi);
		System.out.println(c2.pi);
		System.out.println(c3.pi);

		Circle2.pi=5.0;  //Best practice to use class name to invoke static keyword.
				
		System.out.println(Circle2.pi);
		

		
	
		c1=null;
		c2=null;
		c3=null;
	}

}
