
public class Employee {
	double basicSalary;
	char grade;
	
	
	
	public Employee(double basicSalary, char grade) {
		super();
		this.basicSalary = basicSalary;
		this.grade = grade;
	}

	public Employee() {
		super();
	}



	double computwAllowance() {
		double result;
		switch(grade)
		{
		case 'A':
			result=basicSalary*0.40; 
			break;
		case 'B': 
			result=basicSalary*0.35;
			break;
		case 'C': 
			result=basicSalary*0.25;
			break;
		default:
			result=basicSalary;
//		double result=basicSalary*0.35;
//		return result;
	}
		return result;
	}
	
	double computeTax() {
		return basicSalary*0.10;
	}
}
