
public class Assignment1 {
	int i;
	static int j=20;
	
	Assignment1()  // constructor
	{
		System.out.println("welcome");
		print(10);         //calling static method
		printmul(2,6);     //calling instance method
	}
	Assignment1(int i,int j)
	{
		this();           //calling another constructor
		this.i=i;         // accessing instance variable
		this.j=j;          //accessing static variable
		System.out.println(i+j);
	}
	//static method
	static void print(int j)
	{
		System.out.println("This is a Static method");
		System.out.println(j);
		print1();         //calling static method
	}
	//instance method
	void printmul(int i,int j)
	{
		System.out.println("This is a instance variable");
		print(5);            //calling static method
	}
	static void print1()
	{
		System.out.println("This iss second static method");
	}
}
