
public class A {
	int i;
	static int j=50;
	
	void printSquare()
	{
		System.out.println(i*i);
	}
	
	static void print()// when a method doesn't use instance variables, it is eligible for
	                   //static method
	{
		System.out.println(j);
	}
}
