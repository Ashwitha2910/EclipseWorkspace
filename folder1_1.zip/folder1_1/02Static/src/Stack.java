public class Stack {
    
    int[] arr;
    int index;
    
    public Stack() {
        arr=new int[10];
        System.out.println("Stack with 10 elements created");
    }
    
    public Stack(int size) {
        arr=new int[size];
        System.out.println("Stack with " +size+ " elements created");
    }
    
    void push(int n) {
        arr[index]=n;
        index++;
    }
    
    int pop() {
        index--;
        return arr[index];
    }
    
    void print() {
        System.out.print("[");
        for(int i=0;i<index;i++)
        {
        	System.out.print(arr[i]+",");
        }
        System.out.println("]");
    }
}