
public class Main2 {

	public static void main(String[] args) {
		int a,b;
		a=100;
		b=a++;
		System.out.println(b);
		System.out.println(a<1000);
		// TODO Auto-generated method stub

	}

}
