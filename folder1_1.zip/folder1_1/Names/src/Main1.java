
public class Main1 {

	public static void main(String[] args) {
		int age$10;// only $ and _can be used
		// TODO Auto-generated method stub

	}
	public void fun01() {
		
	}
}
