package Pack1;

public class B {

}
