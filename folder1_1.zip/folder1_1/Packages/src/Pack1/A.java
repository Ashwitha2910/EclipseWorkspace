package Pack1;

public class A {

}
