package Pack1;

public class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
