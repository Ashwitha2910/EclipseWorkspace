package Pack3;

public class F {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
