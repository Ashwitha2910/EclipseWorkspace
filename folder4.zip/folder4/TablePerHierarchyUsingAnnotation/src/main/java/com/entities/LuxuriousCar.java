package com.entities;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="LuxCarTable")

public class LuxuriousCar extends Car{
	@Column(name="engine_capacity")
	private int engine_capacity;
	@Column(name="lux_feature")
	private String lux_features;
	
	public int getEngine_capacity() {
		return engine_capacity;
	}
	public void setEngine_capacity(int engine_capacity) {
		this.engine_capacity = engine_capacity;
	}
	public String getLux_features() {
		return lux_features;
	}
	public void setLux_features(String lux_features) {
		this.lux_features = lux_features;
	}
	
	
}
