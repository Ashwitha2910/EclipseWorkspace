package SPELEx;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.spel.standard.SpelExpressionParser;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(javaConfig.class);
		Emp em=context.getBean("emp",Emp.class);
		System.out.println(em.getE_name());
		System.out.println(em.getNumber());
		System.out.println(em.getDept());
		
		SpelExpressionParser obj=new SpelExpressionParser();
		Expression exp=obj.parseExpression("(4000*34)/679");
		System.out.println(exp.getValue());

	}

}
