package SPELEx;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages ="SPELEx")
public class javaConfig {
	static List<String> list=new ArrayList<String>();
	public static List getDept() {
		list.add("HR");
		list.add("Finance");
		return list;
		
	}
}
