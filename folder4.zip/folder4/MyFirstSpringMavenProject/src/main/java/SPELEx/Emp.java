package SPELEx;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class Emp {
	public static int e_id;
	@Value("Bhushan")
	private String e_name;
	
	@Value("#{T(SPELEx.javaConfig).getDept()}")
	private List<String> dept;
	
//	@Value("#{24+24}")  //mathematical expression
//	@Value("#{T(SPELEx.Emp).number()}") //calling static method from same class
	@Value("#{new java.lang.Integer(24)}") //parsing object
	private int number;
	public static int getE_id() {
		return e_id;
	}
	public static void setE_id(int e_id) {
		Emp.e_id = e_id;
	}
	public String getE_name() {
		return e_name;
	}
	public void setE_name(String e_name) {
		this.e_name = e_name;
	}
	public List<String> getDept() {
		return dept;
	}
	public void setDept(List<String> dept) {
		this.dept = dept;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	@Override
	public String toString() {
		return "Emp [e_name=" + e_name + ", dept=" + dept + ", number=" + number + "]";
	}
	
	public static int number()
	{
		return 101;
	}
}
