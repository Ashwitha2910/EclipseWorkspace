package com.lifecycle3;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Employee {
	private String empName;

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Override
	public String toString() {
		return "Employee [empName=" + empName + "]";
	}
		
	@PostConstruct
	public void start()
	{
		System.out.println("Aall objects initialized..");
	}
	@PreDestroy
	public void stop()
	{
		System.out.println("All objects Destroyed..");
	}
}
