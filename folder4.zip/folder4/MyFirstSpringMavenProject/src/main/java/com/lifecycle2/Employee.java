package com.lifecycle2;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Employee implements InitializingBean,DisposableBean{
	private String empName;

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Override
	public String toString() {
		return "Employee [empName=" + empName + "]";
	}
	
	
	public void afterPropertiesSet() throws Exception {
		System.out.println("Property Value set="+this.empName);
		System.out.println("Application Initializing..");
	}

	public void destroy() throws Exception {
		System.out.println("Thi is my destroy method,All objects are destroyed");
		
	}
	
}
