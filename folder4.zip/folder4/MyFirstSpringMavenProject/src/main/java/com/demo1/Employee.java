package com.demo1;

public class Employee {
	private String emp_name;
	private String emp_address;
	
	
	
	public Employee(String emp_name, String emp_address) {
		super();
		this.emp_name = emp_name;
		this.emp_address = emp_address;
	}

	public Employee() {
		super();
	}
	
	@Override
	public String toString() {
		return "Employee [emp_name=" + emp_name + ", emp_address=" + emp_address + "]";
	}
	
	
	
	
}
