package com.demo1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/demo1/beans.xml");
		Employee e=context.getBean("emp1",Employee.class);
		System.out.println(e.toString());



	}

}
