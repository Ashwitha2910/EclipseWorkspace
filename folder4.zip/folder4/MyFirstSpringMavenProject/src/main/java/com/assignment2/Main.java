package com.assignment2;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
public static void main(String[] args) {
	AbstractApplicationContext context=new ClassPathXmlApplicationContext("com/assignment2/beans.xml");
	Person p=context.getBean("person",Person.class);
	System.out.println(p.toString());
	
}
}
