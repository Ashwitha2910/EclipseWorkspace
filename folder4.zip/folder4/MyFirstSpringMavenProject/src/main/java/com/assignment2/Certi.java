package com.assignment2;

public class Certi {
	private String name;

	public Certi(String name) {
		super();
		this.name = name;
	}

	public Certi() {
		super();
	}

	@Override
	public String toString() {
		return "Certi [name=" + name + "]";
	}
	
	
}
