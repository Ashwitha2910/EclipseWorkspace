package Assignment;

public class Student {
	private int studentRollNumber;
	private String studentName;
	private int englishMarks;
	private int historyMarks;
	private int geographyMarks;
	private int mathsMarks;
	public int getStudentRollNumber() {
		return studentRollNumber;
	}
	public void setStudentRollNumber(int studentRollNumber) {
		this.studentRollNumber = studentRollNumber;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getEnglishMarks() {
		return englishMarks;
	}
	public void setEnglishMarks(int englishMarks) {
		this.englishMarks = englishMarks;
	}
	public int getHistoryMarks() {
		return historyMarks;
	}
	public void setHistoryMarks(int historyMarks) {
		this.historyMarks = historyMarks;
	}
	public int getGeographyMarks() {
		return geographyMarks;
	}
	public void setGeographyMarks(int geographyMarks) {
		this.geographyMarks = geographyMarks;
	}
	public int getMathsMarks() {
		return mathsMarks;
	}
	public void setMathsMarks(int mathsMarks) {
		this.mathsMarks = mathsMarks;
	}
	@Override
	public String toString() {
		return "Student RollNumber=" + studentRollNumber + ",\nStudent Name=" + studentName + ",\nEnglish Marks="
				+ englishMarks + ",\nHistory Marks=" + historyMarks + ",\nGeography Marks=" + geographyMarks
				+ ",\nMaths Marks=" + mathsMarks;
	}
	
	public double computePercentage(int e,int h,int g,int m)
	{
		double res=(((e+h+g+m)*100)/400);
		return res;
//		return e;
	}
	
	public void result()
	{
		double res=computePercentage(englishMarks, historyMarks, geographyMarks, mathsMarks);
		if(res>35.00)
			System.out.println("Result: Pass");
		else
			System.out.println("Result: Fail");
	}
}
