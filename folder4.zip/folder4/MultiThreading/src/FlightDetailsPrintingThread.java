
public class FlightDetailsPrintingThread extends Thread{
	public void run()
	{
		String[] arr= {"6E-532","A2-7553"};
		Thread t=Thread.currentThread();
		for(String f:arr)
		{
			System.out.println("\t\t\t"+t.getName()+f);
		}
	}
}
