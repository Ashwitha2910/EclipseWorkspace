
public class BankAccount {
	int balance;

	public BankAccount(int balance) {
		super();
		this.balance = balance;
	}

	public synchronized void withdraw(int amt)
	{
		String name=Thread.currentThread().getName();
//		this.balance=this.balance-amt;
		for(int i=1;i<=amt;i++) {
			
			if(this.balance<=5) {
				try {
					notify();
					wait();
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			}
			
			this.balance=this.balance-1;
			System.out.println(name+" Current Balance "+this.balance);
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		notify();
	}
	
	public synchronized void deposit(int amt)
	{
		String name=Thread.currentThread().getName();
//		this.balance=this.balance+amt;
		for(int i=1;i<=amt;i++) {
			
			if(this.balance>=25) {
				try {
					notify();
					wait();
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			}
			
			this.balance=this.balance+1;
			System.out.println(name+" Current Balance "+this.balance);
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		notify();
	}
	
	
}
