
public class Client1 {
	public static void main(String[] args) throws InterruptedException {
		System.out.println("Process Begins..");
		
		Thread t=Thread.currentThread();
		
		System.out.println("Welcome to ETV");
		for(int i=1;i<=10;i++)
		{
			System.out.println(i);
			t.sleep(5000);
			System.out.println(t.getName());
		}
		System.out.println("GoodBye");
		System.out.println("Process Ends..");
	}
}
