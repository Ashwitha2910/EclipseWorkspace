
public class WithdrawTask implements Runnable{
 BankAccount acc;
 
	public WithdrawTask(BankAccount acc) {
	super();
	this.acc = acc;
}

	@Override
	public void run() {
		this.acc.withdraw(25);
		
	}

}
