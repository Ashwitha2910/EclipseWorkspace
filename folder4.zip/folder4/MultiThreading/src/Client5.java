
public class Client5 {
	public static void main(String[] args) {
		BankAccount acc = new BankAccount(6);
		DepositTask task1 = new DepositTask(acc);
		WithdrawTask task2=new WithdrawTask(acc);
		
		Thread t1=new Thread(task1,"DT");
		t1.start();
		
		Thread t2=new Thread(task2,"WT");
		t2.start();
	}
}
