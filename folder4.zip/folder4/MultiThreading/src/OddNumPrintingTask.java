
public class OddNumPrintingTask implements Runnable{

	@Override
	public void run() {
		Thread tt=Thread.currentThread();
		for(int i=1;i<=100;i=i+2)
		{
			System.out.println(tt.getName()+":"+i);
		}
		
	}

}
