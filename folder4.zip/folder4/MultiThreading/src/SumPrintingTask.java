
public class SumPrintingTask implements Runnable {
	int sum=0;
	@Override
	public synchronized void run() {
		String name=Thread.currentThread().getName();
		System.out.println(name+" [ ");
		int[] nums= {10,20,30,14,6};
		for(int i:nums)
		{
		System.out.println(i+",");
		sum=sum+i;
		try {
			Thread.sleep(500);
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		}
		System.out.println("Sum is "+sum+"]");
		sum=0;
	}

}
