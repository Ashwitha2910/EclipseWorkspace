
public class Client2 {
	public static void main(String[] args) {
		Thread t1;
		Runnable task1=new CityPrintingTask();
		//t1=new Thread(task1); //Default name Thread-0 will be printed
		t1=new Thread(task1,"CPT");//Thread is given a name CPT
		t1.start();
		
		Runnable task2=new NumberPrintingTask();
		Thread t2;
		t2=new Thread(task2,"NPT");
		t2.start();

		Runnable task3=new OddNumPrintingTask();
		Thread t3;
		t3=new Thread(task3,"ONPT");
		t3.start();
		
		Thread task4=new FlightDetailsPrintingThread();
		Thread t4;
		t4=new Thread(task4,"FNPT");
		t4.start();
		
		Thread t5=new Thread (task1,"citius");
		t5.start();
		
		Thread t6=new Thread (task2,"Tech");
		t6.start();
	}
}
