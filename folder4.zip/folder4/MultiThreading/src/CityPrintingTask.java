
public class CityPrintingTask implements Runnable{

	@Override
	public void run() {
		String[] cities=new String[5];
		cities[0]="Bangalore";
		cities[1]="Mumbai";
		cities[2]="Delhi";
		cities[3]="Pune";
		cities[4]="Hyderabad";
		for(int i=0;i<cities.length;i++)
		{
			Thread t=Thread.currentThread();
			System.out.println(t.getName()+":"+cities[i]);
		}

		
	}
	
}
