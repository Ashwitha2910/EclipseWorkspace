
public class Client3 {

	public static void main(String[] args) {
		
		Runnable r1=new NumberPrintingTask();
		Thread t1=new Thread(r1,"NPT");
		t1.start();
		
		try {
			t1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		String name=Thread.currentThread().getName();
		String[] countries= {"UK","USA","Spain","Germany","India"};
		for(String country:countries)
		{
			System.out.println(name+" : "+country);
		}
		System.out.println(name+" Thread Ending...");
		System.out.println(t1.isAlive());
	}

}
