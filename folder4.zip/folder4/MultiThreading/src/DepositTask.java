
public class DepositTask implements Runnable{

	BankAccount acc;
	
	public DepositTask(BankAccount acc) {
		super();
		this.acc = acc;
	}

	@Override
	public void run() {
		this.acc.deposit(30);
		
	}

}
