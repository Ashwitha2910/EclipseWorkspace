import java.util.Scanner;

public class NumberPrintingTask implements Runnable{

	@Override
	public void run() {
		Thread t=Thread.currentThread();
		for(int i=1;i<=20;i++)
		{
			System.out.println("\t\t"+t.getName()+":"+i);
			Scanner sc=new Scanner(System.in);
			
		}
		
	}

}
