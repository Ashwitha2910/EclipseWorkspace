package com.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.model.Emp;

public class EmpDaoImpl implements EmpDao{

	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insertEmployee(Emp emp) {
		String query="insert into Emp values(?,?)";
		int res=this.jdbcTemplate.update(query,emp.getEmp_id(),emp.getEmp_name());
		return res;
	}

	public int deleteEmployee(Emp emp) {
		String query="delete from Emp where emp_id=?";
		int res=this.jdbcTemplate.update(query,emp.getEmp_id());
		return res;
	}

	public int updateEmployee(Emp emp) {
		String query="update Emp set emp_name=? where emp_id=?";
		int res=this.jdbcTemplate.update(query,emp.getEmp_name(),emp.getEmp_id());
		return res;
	}

	public Emp getEmp(int emp_id) {
		String query="select * from Emp where emp_id=?";
		RowMapper<Emp> rm=new RowMapperImpl();
		Emp emp=this.jdbcTemplate.queryForObject(query, rm,emp_id);
		return emp;
	}

	public List<Emp> getAllEmployees() {
		String query="select * from Emp";
		RowMapper<Emp> rm=new RowMapperImpl();
		List<Emp> list=this.jdbcTemplate.query(query, rm);
		return list;
	}

}
