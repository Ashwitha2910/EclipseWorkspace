package com.view;

import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.EmpDaoImpl;
import com.model.Emp;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("bean.xml");
		EmpDaoImpl emp=context.getBean("empDao",EmpDaoImpl.class);
		
		Emp e1=new Emp();
//		e1.setEmp_id(1);
//		e1.setEmp_name("Ashwitha");
//		int res=emp.insertEmployee(e1);
//		int res=emp.deleteEmployee(e1);
//		int res=emp.updateEmployee(e1);
//		System.out.println(res+" updated");
		
//		Emp e2=emp.getEmp(1);
//		System.out.println(e2.getEmp_id()+"-->"+e2.getEmp_name());
		
		List<Emp> l=emp.getAllEmployees();
//		System.out.println(l);
		for (Iterator iterator = l.iterator(); iterator.hasNext();) {
			Emp emp2 = (Emp) iterator.next();
			System.out.println(emp2.getEmp_id()+"-->"+emp2.getEmp_name());
			
		}
		
		

	}

}
