package com.entities;

public class LuxuriousCar extends Car{
	private int engine_capacity;
	private String lux_features;
	
	public int getEngine_capacity() {
		return engine_capacity;
	}
	public void setEngine_capacity(int engine_capacity) {
		this.engine_capacity = engine_capacity;
	}
	public String getLux_features() {
		return lux_features;
	}
	public void setLux_features(String lux_features) {
		this.lux_features = lux_features;
	}
	
	
}
