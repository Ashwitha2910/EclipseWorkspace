package com.driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.entities.Car;
import com.entities.EconomicalCar;
import com.entities.LuxuriousCar;

public class Main {

	public static void main(String[] args) {
		Car car=new Car();
		EconomicalCar ecoCar=new EconomicalCar();
		LuxuriousCar luxCar=new LuxuriousCar();
		
		car.setCar_name("Maruti");
		ecoCar.setCar_name("Alto New");
		ecoCar.setCar_milage(22);
		ecoCar.setCar_price(4.5f);
		luxCar.setCar_name("Audi A7");
		luxCar.setEngine_capacity(3000);
		luxCar.setLux_features("Loaded with all features");
		
		Configuration config=new Configuration();
		config.configure();
		SessionFactory sf=config.buildSessionFactory();
		Session s=sf.openSession();
		Transaction tran=s.beginTransaction();
		s.save(car);
		s.save(ecoCar);
		s.save(luxCar);
		tran.commit();
	}

}
