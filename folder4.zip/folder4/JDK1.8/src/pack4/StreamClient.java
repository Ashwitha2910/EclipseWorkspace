package pack4;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import pack3.Student;


public class StreamClient {

	public static void main(String[] args) {
		Collection<Employee> ce=new ArrayList<>();
		ce.add(new Employee(100,"Akash",'B',20000));
		ce.add(new Employee(102,"Bhushan",'A',50000));
		ce.add(new Employee(104,"Karthik",'A',60000));
		ce.add(new Employee(105,"Nilesh",'D',40000));
		ce.add(new Employee(103,"Razaa",'C',55000));
		
		Stream<Employee> st1=ce.stream();
//		st1.sorted().forEach((t)->System.out.println(t));
//		st1.sorted().filter((e)->e.getBasicSalary()>50000).forEach((e)->System.out.println(e));

		List<Employee> emp1=st1.sorted(new SalaryComparator()).collect(Collectors.toList());
		System.out.println(emp1);
		
		Stream<Employee> st2=ce.stream();
		
		Optional<Employee> search=st2.parallel().filter((e)->e.getGrade()=='A').findAny();
		if(search.isPresent())
		{
			System.out.println(search.get());
		}
		
		Stream<Employee> st3=ce.stream();
		List<Double> allNames=st3.map((e)->e.getBasicSalary()).collect(Collectors.toList());
		System.out.println(allNames);
		
		Collection<Student> ss= new ArrayList<>();
		ss.add(new Student("Ashwitha",80,79));
		ss.add(new Student("Suksham",98,89));
		ss.add(new Student("Sandeep",68,79));
		ss.add(new Student("Bhushan",45,69));
		ss.add(new Student("Shravan",77,89));

		Stream<Student> chi=ss.stream();
		List<String> nm=chi.map((y)->y.getName()).collect(Collectors.toList());
		System.out.println(nm);
	}
}
