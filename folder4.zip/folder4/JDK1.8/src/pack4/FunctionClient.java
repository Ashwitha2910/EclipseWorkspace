package pack4;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.function.Function;
import java.util.stream.Stream;

import pack3.Circle;
import pack3.Student;

public class FunctionClient {
	public static void main(String[] args) {
		Function<Circle,Double> f1;
		
		f1=(c)->c.area();
		
		Circle c=new Circle(10);
		Double d=f1.apply(c);
		System.out.println(d);
		
		Function<Student,Integer> f2;
		f2=(s)->s.getTotal();
		Student s=new Student("Rahul",70,80);
		
		Integer total=f2.apply(s);
		System.out.println(total);
		
		Collection<String> cities=new ArrayList<String>();
		cities.add("Delhi");
		cities.add("Mumbai");
		cities.add("Bangalore");
		cities.add("Mangalore");
		cities.add("Pune");
		
		System.out.println(cities);
		
		cities.forEach((e)->{
			System.out.println(e.length());
		});
		
		cities.forEach((r)->{
			System.out.println(r.toUpperCase());
		});
		
		Collection<Circle> cir=new HashSet<>();
		cir.add(new Circle(90));
		cir.add(new Circle(100));
		cir.add(new Circle(10));
		cir.add(new Circle(45));
		cir.add(new Circle(120));
		cir.add(new Circle(80));


		
		cir.forEach((a)->
			System.out.println(a.area()));
		
		Stream<Circle> stream1=cir.stream();
		stream1.filter((a)->a.getRad()>50).sorted().forEach((b)->System.out.println(b));
		
		
	}
}
