package pack1;

public interface C {
	default void m2()
	{
		System.out.println("m2 in C");
	}
}
