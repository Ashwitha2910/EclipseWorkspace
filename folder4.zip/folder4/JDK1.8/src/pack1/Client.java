package pack1;
public class Client {
	public static void main(String[] args) {
		A ref=new B();
		ref.m2();
		ref.m3();
		A.m1();
	}
}
