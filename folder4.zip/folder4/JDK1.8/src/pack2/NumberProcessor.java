package pack2;

@FunctionalInterface
public interface NumberProcessor {
	void process(Integer i);
}
