package pack2;

public class Client3 {
	
	static void testing(NumberProcessor np) {
		np.process(5);
	}
	
	public static void main(String[] args) {
		NumberProcessor np1=(n)->{
			System.out.println(n.doubleValue());
		};
		np1.process(new Integer(30));
		
		NumberProcessor np2=(n)->{
			System.out.println(n.intValue());
		};
		np2.process(new Integer(60));
		
		NumberProcessor np3=(n)->System.out.println(n.floatValue());
		np3.process(89);
		
		NumberProcessor np4=(n)->System.out.println(n*n);
		testing(np4);
		
		testing((n)->{System.out.println(n*n*n);});
		
	}
}
