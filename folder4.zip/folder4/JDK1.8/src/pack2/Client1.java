package pack2;

public class Client1 {
	
	static void print(Loan loan) {
		System.out.println(loan.getInterestRate());
	}
	
	public static void main(String[] args) {
		Loan loan;
		
		//Anonymous class definition
		loan=new Loan() {
			
			@Override
			public double getInterestRate() {
				
				return 0.20;
			}
		};
	print(loan);
		
		loan=new Loan() {
			
			@Override
			public double getInterestRate() {
				// TODO Auto-generated method stub
				return 0.35;
			}
		};
		print(loan);
		
		//Lambda Expressions
		loan=()->{
			return 0.87;
		};
		print(loan);
		
		loan=()->0.90;
		print(loan);
	}

}
