package pack2;

public class CarLoan implements Loan{

	@Override
	public double getInterestRate() {
		
		return 0.15;
	}

}
