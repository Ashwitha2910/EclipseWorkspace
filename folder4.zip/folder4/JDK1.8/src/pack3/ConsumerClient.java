package pack3;

import java.util.function.Consumer;

public class ConsumerClient {
	

static void demo1(Consumer<Integer> c) {
	c.accept(600);
}

	
	public static void main(String[] args) {
		Consumer<String> c1=(s)->System.out.println(s.toUpperCase());
		
		c1.accept("hello");
		
		Consumer<Integer> c2=(i)->{
			System.out.println(i.intValue());
			System.out.println(i.doubleValue());
		};
		demo1(c2);
		
		demo1((n)->{
			System.out.println(n.floatValue());
			System.out.println(n.doubleValue());
		});
		
		demo1((n)->System.out.println(n*n));
		
		
		Consumer<Student> cs;
		cs=(s)->s.getTotal()>100;
		Student st=new Student("Sha",45,62);
		demo1(cs);
		
	}
}
