package pack3;

import java.util.function.Predicate;

public class PredicateClient {
	
	public static void main(String[] args) {
//		Predicate<String> p1;
//		p1=(s)->s.length()>10;
//		
//		System.out.println(p1.test("Hellooooooooooooooooo"));
//		System.out.println(p1.test("Hello"));
//		
//		Predicate<Integer> p2;
//		p2=(i)->i%100==0;
//		
//		System.out.println(p2.test(300));
//		
//		Predicate<Student> p3;
//		p3=(s)->s.getTotal()>100;
//		
//		Student h=new Student("Ash",80,16);
//		
//		System.out.println(p3.test(h));
		
		Predicate<Circle> cc;
		cc=(d)->d.area()>100;
		
		Circle ccc=new Circle(45);
		System.out.println(cc.test(ccc));

	}
}
