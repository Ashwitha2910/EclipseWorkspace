package pack3;

public class Circle implements Comparable<Circle>{
	 public int rad;
	 
	 
	 public Circle(int rad) {
		super();
		this.rad = rad;
	}


	public int getRad() {
		return rad;
	}


	public void setRad(int rad) {
		this.rad = rad;
	}


	public double area()
	 {
		 return 3.14*this.rad*this.rad;
	 }


	@Override
	public String toString() {
		return "Circle [rad=" + rad + "]";
	}

	public int compareTo(Circle o) {
		return this.rad-o.rad;
	}
	
	
}
