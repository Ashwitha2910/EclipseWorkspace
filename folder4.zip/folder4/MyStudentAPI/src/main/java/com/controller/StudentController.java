package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Student;

@RestController
@RequestMapping("/api")
public class StudentController {
	static List<Student> list;
	
	@PostConstruct
	public void load() {
		System.out.println("Bhushan");
		list=new ArrayList<Student>();
		list.add(new Student("John","Cena"));
		list.add(new Student("Dean","Ambrose"));
		list.add(new Student("Suksham","Sukhi"));
		list.add(new Student("Shravan","Kumar"));
		list.add(new Student("Ashwitha","Prabhu"));
		System.out.println(list);
		
	}
	
//	public void afterPropertiesSet() throws Exception {
//		System.out.println("Bhushan");
//		list=new ArrayList<Student>();
//		list.add(new Student("John","Cena"));
//		list.add(new Student("Dean","Ambrose"));
//		list.add(new Student("Suksham","Sukhi"));
//		list.add(new Student("Shravan","Kumar"));
//		list.add(new Student("Ashwitha","Prabhu"));
//		System.out.println(list);
//		
//	}
	
	@GetMapping("/students")
	public List<Student> getStudents()
	{
		return list;
	}

	
}
