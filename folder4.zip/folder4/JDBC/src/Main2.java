import java.sql.Statement;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Main2  {

	public static void main(String[] args)throws ClassNotFoundException, SQLException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		String url="jdbc:sqlserver://localhost\\MSSQLSERVER;databaseName=DBTraining;trustServerCertificate=true;";
		String username="sa";
		String password="password_123";
		
		Connection con=DriverManager.getConnection(url,username,password);
		int  id;
		String name;
		double salary;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter ID: ");
		id=sc.nextInt();
		
		System.out.println("Enter Name: ");
		name=sc.next();
		
		System.out.println("Enter Salary: ");
		salary=sc.nextDouble();
		
		String sql="select * employee where eid=?;";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1,id);
		ps.setString(2,name);
		ps.setDouble(3,salary);

		int rowaffected=ps.executeUpdate();
		System.out.println(rowaffected);
        sc.close();
        con.close();
	}

}
