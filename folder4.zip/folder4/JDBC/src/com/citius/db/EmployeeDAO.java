package com.citius.db;

 

import java.sql.Connection;
import java.util.List;

 

import com.citius.bin.Employee;

 

public interface EmployeeDAO {
        String INSERT_SQL="insert into Employee values(?,?,?);";
        String READ_ALL_SQL="select * from Employee";
        String SEARCH_SQL="select * from Employee where EID=?";
        String DELETE_SQL="delete from Employee where EID=?";

        boolean addEmployee(Connection con,Employee emp);
        boolean removeEmployee(Connection con,Employee emp);
        Employee searchEmployee(Connection con,Employee emp);

        List<Employee>getAllEmployees(Connection con);
}