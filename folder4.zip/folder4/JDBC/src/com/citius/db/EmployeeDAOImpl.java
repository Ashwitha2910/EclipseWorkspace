package com.citius.db;

 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

 

import com.citius.bin.Employee;

 

public class EmployeeDAOImpl implements EmployeeDAO {

 

    @Override
    public boolean addEmployee(Connection con, Employee emp) {
        boolean result=false;
        try {
        PreparedStatement st=con.prepareStatement(INSERT_SQL);
        st.setInt(1,emp.getId());
        st.setString(2,emp.getName());
        st.setDouble(3,emp.getBasic());

        int r=st.executeUpdate();
        if(r==1)
            result=true;
        }catch(Exception e) {
            e.printStackTrace();
        }
        return result;
    }


 

    @Override
    public boolean removeEmployee(Connection con, Employee emp) {
        boolean result=false;
        try {
            PreparedStatement st=con.prepareStatement(DELETE_SQL);
            st.setInt(1,emp.getId());
            int r=st.executeUpdate();
            if(r==1)
                result=true;
            }catch(Exception e) {
                e.printStackTrace();
            }
        return result;
    }


 

    @Override
    public Employee searchEmployee(Connection con, Employee emp) {
        Employee empl=null;
        try {
            PreparedStatement st=con.prepareStatement(SEARCH_SQL);
            st.setInt(1,emp.getId());

            ResultSet rs=st.executeQuery();
            if(rs.next()) {
                empl=new Employee(rs.getInt(1),rs.getString(2),rs.getDouble(3));
            }
        }catch(Exception e) {
            e.printStackTrace();
        }        
        return empl;
    }


 

    @Override
    public List<Employee> getAllEmployees(Connection con) {
        List <Employee> allEmp=new ArrayList<Employee>();
        try {
            PreparedStatement st=con.prepareStatement(READ_ALL_SQL);

            ResultSet rs=st.executeQuery();

            while(rs.next()) {
                Employee emp=new Employee(rs.getInt(1),rs.getString(2),rs.getDouble(3));
                allEmp.add(emp);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }
        return allEmp;
    }

}