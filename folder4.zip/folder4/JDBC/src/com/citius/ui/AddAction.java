package com.citius.ui;

 

import java.sql.Connection;
import java.util.Scanner;

 

import com.citius.bin.Employee;
import com.citius.db.ConnectionManager;
import com.citius.db.EmployeeDAO;
import com.citius.db.EmployeeDAOImpl;

 

public class AddAction extends Action{

 

    @Override
    public void init() {
        System.out.println("Adding Employee");
        System.out.println("================");

    }

 

    @Override
    public void execute() {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter ID:");
        int id=sc.nextInt();

        System.out.println("Enter Name:");
        String name=sc.next();

        System.out.println("Enter Salary:");
        double salary=sc.nextDouble();

        Employee e=new Employee(id,name,salary);
        Connection con=ConnectionManager.createConnection();
        EmployeeDAO dao=new EmployeeDAOImpl();
        if(dao.addEmployee(con, e)==true)
            System.out.println("Employee Added");
        else
            System.out.println("Employee not Added");

    }

 

}