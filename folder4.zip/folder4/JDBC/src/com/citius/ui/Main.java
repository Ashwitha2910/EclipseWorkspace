package com.citius.ui;

 

public class Main {

 

    public static void main(String[] args) {
        MenuHandler mh=new MenuHandler();
        mh.handleMenu();
    }

 

}