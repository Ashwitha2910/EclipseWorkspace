package com.citius.ui;

 

import java.util.Scanner;

 

public class MenuHandler {

    public void displayMenu() {
        String[] mItems= {
                "Add Employee",
                "List all Employees",
                "Search Employee",
                "Remove Employee",
                "Exit"
        };

        for(int i=0;i<mItems.length;i++) {
            System.out.println((i+1)+"."+mItems[i]);
        }
    }

    public int promptForChoice() {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your choice:");
        int ch=sc.nextInt();
        return ch;
    }

    public void handleMenu() {
        while(true) {
            this.displayMenu();
            int ch=this.promptForChoice();

            Action ac=null;

            switch(ch) {
            case Actions.ADD:
                ac=new AddAction();
                ac.go();
                break;
            case Actions.LISTALL:
                ac=new ListAction();
                ac.go();
                break;
            case Actions.SEARCH:
                ac=new SearchAction();
                ac.go();
                break;
            case Actions.REMOVE:
                ac=new RemoveAction();
                ac.go();
                break;
            case Actions.EXIT:System.exit(0);
            }
        }

    }
}