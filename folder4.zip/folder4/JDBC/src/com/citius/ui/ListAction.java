package com.citius.ui;

 

import java.sql.Connection;

 

import com.citius.db.ConnectionManager;
import com.citius.db.EmployeeDAO;
import com.citius.db.EmployeeDAOImpl;

 

public class ListAction extends Action {

 

    @Override
    public void init() {
        System.out.println("Listing all Employees");
        System.out.println("================");

    }

 

    @Override
    public void execute() {

        Connection con=ConnectionManager.createConnection();
        EmployeeDAO dao=new EmployeeDAOImpl();
        System.out.println(dao.getAllEmployees(con));
        ConnectionManager.closeConnection(con);
    }

 

}