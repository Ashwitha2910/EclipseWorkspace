package com.citius.ui;

public abstract class Actions {
	public static final int ADD=1;
	public static final int LISTALL=2;
	public static final int SEARCH=3;
	public static final int REMOVE=4;
	public static final int EXIT=5;

}
