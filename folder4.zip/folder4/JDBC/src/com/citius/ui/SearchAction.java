package com.citius.ui;

 

import java.sql.Connection;
import java.util.Scanner;

 

import com.citius.bin.Employee;
import com.citius.db.ConnectionManager;
import com.citius.db.EmployeeDAO;
import com.citius.db.EmployeeDAOImpl;

 

public class SearchAction extends Action {

 

    @Override
    public void init() {
        System.out.println("Searching Employee");
        System.out.println("================");

    }

 

    @Override
    public void execute() {
        Scanner sc=new Scanner(System.in);

        System.out.println("Enter employee ID to search:");
        int id=sc.nextInt();

        Employee e=new Employee(id);
        Connection con=ConnectionManager.createConnection();
        EmployeeDAO dao=new EmployeeDAOImpl();
        System.out.println(dao.searchEmployee(con, e));
    }
}