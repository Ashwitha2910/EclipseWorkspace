package com.citius.ui;

 

import java.sql.Connection;
import java.util.Scanner;

 

import com.citius.bin.Employee;
import com.citius.db.ConnectionManager;
import com.citius.db.EmployeeDAO;
import com.citius.db.EmployeeDAOImpl;

 

public class RemoveAction extends Action {

 

    @Override
    public void init() {
        System.out.println("Removing Employee");
        System.out.println("================");

    }

 

    @Override
    public void execute() {
        Scanner sc=new Scanner(System.in);

        System.out.println("Enter employee ID to remove:");
        int id=sc.nextInt();

        Employee e=new Employee(id);
        Connection con=ConnectionManager.createConnection();
        EmployeeDAO dao=new EmployeeDAOImpl();
        System.out.println(dao.searchEmployee(con, e));
        if(dao.removeEmployee(con, e)==true)
            System.out.println("Employee Removed");
        else
            System.out.println("Employee Not Removed");

    }

 

}