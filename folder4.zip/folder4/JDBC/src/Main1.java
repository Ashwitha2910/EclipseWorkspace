import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Main1 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		String url="jdbc:sqlserver://localhost\\MSSQLSERVER;databaseName=DBTraining;trustServerCertificate=true;";
		String username="sa";
		String password="password_123";
		
		Connection con=DriverManager.getConnection(url,username,password);

		Statement st=con.createStatement();
		
		String sql="select * from employee where eid=101";
		
		ResultSet rs=st.executeQuery(sql);
//		rs.next();//returns boolean value
		
		while(rs.next())
		{
		System.out.print(rs.getInt(1));
		System.out.print("\t"+rs.getString(2));
		}
		
		rs.close();
		st.close();
//		int rowsAffected=st.executeUpdate(sql);
//		System.out.println(rowsAffected);
		
		con.close();//very important
		
		
	}

}
