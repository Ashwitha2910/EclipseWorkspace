import java.sql.Statement;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class Main3 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		String url="jdbc:sqlserver://localhost\\MSSQLSERVER;databaseName=DBTraining;trustServerCertificate=true;";
		String username="sa";
		String password="password_123";
		
		Connection con=DriverManager.getConnection(url,username,password);
		int  id;
		String name;
		double salary;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter ID: ");
		id=sc.nextInt();

		
		String sql="select * from employee where eid=?;";
	

		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1,id);
		ResultSet rs=ps.executeQuery();
		

		while(rs.next())
		{
			System.out.print(rs.getInt(1));
			System.out.print("\t"+rs.getString(2));
			System.out.print("\t"+rs.getDouble(3));

		}

        sc.close();
        con.close();

	}

}
