package com.model;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class App 
{
	
    public static void main( String[] args )
    {
    	ObjectMapper mapper=new ObjectMapper();
        try {
			Student student=mapper.readValue(new File("Data/Student-info.json"), Student.class);
			System.out.println(student.getId());
			System.out.println(student.getFirst_name());
			System.out.println(student.getAddress());
			System.out.println(student.getAddress().getCity());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
        
    }
}

