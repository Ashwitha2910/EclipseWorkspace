
public class Main4 {

	public static void main(String[] args) {
		System.out.println("wel\tcom\u0065");//objects
		System.out.println("");
		System.out.println();
		// TODO Auto-generated method stub

	}

}
