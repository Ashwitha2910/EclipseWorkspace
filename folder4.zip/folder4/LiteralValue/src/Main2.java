
public class Main2 {

	public static void main(String[] args) {
		System.out.println(80.4535f);//float
		System.out.println(90.034);//double
		System.out.println(1.0e2);
		System.out.println(1.0e-2);//1.0pow 1/2

	}

}
