
public class Main1 {

	public static void main(String[] args) {
		int age=45;
		System.out.println(++age);
		System.out.println(50.34);
		System.out.println(050);//0-7 Octal number
		System.out.println(0x11);//Hexadecimal
		System.out.println(0b1101);//binary
		System.out.println(80L);//Long literal->8bytes

	}

}
