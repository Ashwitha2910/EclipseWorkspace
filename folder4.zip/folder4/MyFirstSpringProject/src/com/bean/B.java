package com.bean;

public class B {
	private int nm1;

	public int getNm1() {
		return nm1;
	}

	public void setNm1(int nm1) {
		this.nm1 = nm1;
	}

	public B(int nm1) {
		super();
		this.nm1 = nm1;
	}

	public B() {
		super();
	}

	@Override
	public String toString() {
		return "B [nm1=" + nm1 + "]";
	}
	
}
