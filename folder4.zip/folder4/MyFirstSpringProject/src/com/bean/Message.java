package com.bean;

public class Message {
	private String msg;

	public Message(String msg) {
		super();
		this.msg = msg;
	}

	public Message() {
		super();
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "Message [msg=" + msg + "]";
	}

	
	
	
}
