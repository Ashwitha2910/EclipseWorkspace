package com.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/bean/beans.xml");
//		Message m=context.getBean("mes",Message.class);
//		System.out.println(m.getMsg());
		
//		Student st=context.getBean("student1",Student.class);
//		System.out.println(st.getF_name());
//		System.out.println(st.toString());
//		Student st1=context.getBean("student2",Student.class);
//		System.out.println(st1.getF_name());
		
		Student st=context.getBean("student",Student.class);
		System.out.println(st.toString());
		System.out.println(st.getListOfFriends());
		
		A a= context.getBean("aref",A.class);
		System.out.println(a.toString());
		
	}

}
