package com.bean;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Student {
	private List<String> listOfFriends;
	private Map<Integer,String> course;
	private Set<String> phoneNumber;
	public List<String> getListOfFriends() {
		return listOfFriends;
	}
	public void setListOfFriends(List<String> listOfFriends) {
		this.listOfFriends = listOfFriends;
	}
	public Map<Integer, String> getCourse() {
		return course;
	}
	public void setCourse(Map<Integer, String> course) {
		this.course = course;
	}
	public Set<String> getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Set<String> phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	@Override
	public String toString() {
		return "Student [listOfFriends=" + listOfFriends + ", course=" + course + ", phoneNumber=" + phoneNumber + "]";
	}
	
	
}
