package com.bean;

public class A {
	private int num1;
	private B num2;
	public int getNum1() {
		return num1;
	}
	public void setNum1(int num1) {
		this.num1 = num1;
	}
	public B getNum2() {
		return num2;
	}
	public void setNum2(B num2) {
		this.num2 = num2;
	}
	@Override
	public String toString() {
		return "A [num1=" + num1 + ", num2=" + num2 + "]";
	}
	
	
}
