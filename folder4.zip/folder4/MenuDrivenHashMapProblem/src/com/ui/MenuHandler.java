package com.ui;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

import com.controller.HashMapOperations;

public class MenuHandler {
	public void displayMenu() {
		String[] items = { "Get Country By Capital", "Get Capital By Country", };
		for (int i = 0; i < items.length; i++) {
			System.out.println((i + 1) + "." + items[i]);
		}
	}

	public HashMap<String, String> getMap() {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("India", "Delhi");
		map.put("SouthKorea", "Seoul");
		map.put("Japan", "Tokyo");
		map.put("Russia", "Moscow");
		map.put("Germany", "Berlin");
		return map;
	}

	public int selectOption() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice or enter 0 to exit");
		int choice = sc.nextInt();
		return choice;
	}

	public void handleMenu() {
		this.displayMenu();
		HashMap<String,String> hmap=this.getMap();
		int ch = this.selectOption();
		HashMapOperations hmapOp=new HashMapOperations();
		Scanner s = new Scanner(System.in);
		switch (ch) {

		case 1:
			System.out.println("Enter Capital: ");
			String capital = s.next();	
			hmapOp.getCountryByCapital(capital);
			break;
		case 2:
			System.out.println("Enter Country: ");
			String country = s.next();
			hmapOp.getCapitalByCountry(country);
			break;
		case 0:
			System.exit(0);

		}
	}
}
