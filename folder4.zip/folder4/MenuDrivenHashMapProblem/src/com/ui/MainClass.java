package com.ui;

import java.util.HashMap;

public class MainClass {

	public static void main(String[] args) {
		MenuHandler mh=new MenuHandler();
		mh.handleMenu();
	}

}
