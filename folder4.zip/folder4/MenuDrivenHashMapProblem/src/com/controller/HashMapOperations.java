package com.controller;

import java.util.HashMap;
import java.util.Map;

import com.ui.MenuHandler;

public class HashMapOperations {
	
	public void getCountryByCapital(String cap) {
		MenuHandler menu=new MenuHandler();
		HashMap<String,String> hmap=menu.getMap();
		for (Map.Entry<String, String> entry : hmap.entrySet()) {
			if(cap.equals(entry.getValue()))
			{
				System.out.println(entry.getKey());
			
		}
		}
}
	
	public void getCapitalByCountry(String country) {
		MenuHandler menu=new MenuHandler();
		HashMap<String,String> hmap=menu.getMap();
		for (Map.Entry<String, String> entry : hmap.entrySet()) {
			
			if(country.equals(entry.getKey())) {
				System.out.println(country+"==>"+entry.getValue());
			}
			
		}
	}
}