
public class SalesEmployee extends Employee{
	String areaName;
	int secount=0;
	
	
	public String getAreaName() {
		return areaName;
	}


	public SalesEmployee() {
		super();
	}


	public SalesEmployee(int id, String name, double basicSalary, String areaName) {
		super(id, name, basicSalary);
		this.areaName = areaName;
	}


	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}


	@Override
	double getNetSalary()
	{
		return super.getNetSalary()+5000;
	}

}
