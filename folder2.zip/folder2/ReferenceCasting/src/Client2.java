
public class Client2 {
	public static void main(String[] args) {
		Employee o=new Employee();
		 Object o1=new Circle();
		 System.out.println(o1.toString());
		 o1=new Student();
		 System.out.println(o1.toString());
		 
		o1=new Employee();
		System.out.println(o1.toString());
	}
}
