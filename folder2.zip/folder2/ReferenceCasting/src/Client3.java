	
public class Client3 {

	public static void main(String[] args) {
		Circle[] c=new Circle[5];
		c[0]=new Circle(10);
		c[1]=new Circle(12);
		c[2]=new Circle(14);
		c[3]=new Circle(16);
		c[4]=new Circle(18);
		double max=0;
		for(Circle s:c)
			System.out.println("The area for radius "+s.rad+" is "+s.computeArea());
		
		Employee[] e=new Employee[3];
		e[0]=new Employee(101,"Ashwitha",40000);
		e[1]=new Employee(103,"Shishir",50000);
		e[2]=new Employee(107,"Prajna",45000);
		
		for(int i=0;i<e.length;i++)
		{
			System.out.println(e[i]);
			System.out.println(e[i].getNetSalary());
			if(max<e[i].getNetSalary())
				max=e[i].getNetSalary();
		}
		
//			if(max<e[0])
//			{
//				max=h;
//			}
		System.out.println("Highest Salary is: "+max);

		
	}

}
