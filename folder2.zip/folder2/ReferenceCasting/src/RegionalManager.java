
public class RegionalManager extends Manager{
	String regionName;
	int rcount=0;
	
	
	public String getRegionName() {
		return regionName;
	}





	public RegionalManager(int id, String name, double basicSalary, int empCount, String regionName) {
		super(id, name, basicSalary, empCount);
		this.regionName = regionName;
	}





	public RegionalManager(String regionName) {
		super();
		this.regionName = regionName;
	}





	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}


	@Override
	double getNetSalary()
	{
		return super.getNetSalary()+20000.00;
	}
}
