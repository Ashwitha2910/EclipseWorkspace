
public class Client {

	public static void main(String[] args) {
		Employee employee=new SalesEmployee();//Upcasting

//		Manager manager=(Manager)employee;
		SalesEmployee se=(SalesEmployee)employee;//downcasting
		
		Object obj=new Circle();
		System.out.println(obj.toString());
		System.out.println(obj.hashCode());
		
		Circle temp=(Circle)obj;
		temp.rad=20;
		System.out.println(temp.computeArea());
		
		Object o=new Student();
		System.out.println(o.toString());
		System.out.println(o.hashCode());
		
		Student s=(Student)o;
		s.mark1=77;
		s.mark2=86;
		System.out.println(s.getTotal());
		
		Object o1=new Employee();
		System.out.println(o1.toString());
		System.out.println(o1.hashCode());
		
		Employee e=(Employee)o1;
		e.basicSalary=20000;
		System.out.println("Total Allowance :"+e.computeAllowance());
		System.out.println("Total Tax :"+e.computeTax());
		System.out.println("Net Salary :"+e.getNetSalary());
		
		Employee e1=new Manager();
		Manager m=(Manager)e1;
		m.empCount=20;
		m.basicSalary=30000;
		System.out.println(m.computeAllowance());
		System.out.println(m.computeTax());
		System.out.println(m.getNetSalary());
		

	}

}
