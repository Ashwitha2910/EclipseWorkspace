
public class Circle {
	int rad;
	int count=0;
	public Circle() {
		super();
	}
	
	public Circle(int rad) {
		super();
		this.rad = rad;
	}

	double computeArea()
	{
		return 3.14*this.rad*this.rad;
	}
	@Override
	public String toString() {
		return "Circle [rad=" + rad + "]";
	}
	
}
