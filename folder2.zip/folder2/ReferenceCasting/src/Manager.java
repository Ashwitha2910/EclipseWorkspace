
public class Manager extends Employee {
	int empCount;
	int mcount=0;
	
		
	public Manager() {
		super();
	}

	public Manager(int id, String name, double basicSalary, int empCount) {
		super(id, name, basicSalary);
		this.empCount = empCount;
	}

	public int getEmpCount() {
		return empCount;
	}

	public void setEmpCount(int empCount) {
		this.empCount = empCount;
	}

	@Override
	double getNetSalary()
	{
		return super.getNetSalary()+(this.empCount*100);
	}

	@Override
	public String toString() {
		return "Manager [empCount=" + empCount + "]";
	}
	

}
