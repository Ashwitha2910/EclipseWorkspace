
public class Employee {
	int id;
	String name;
	double basicSalary;
    int ecount=0;
	
	public Employee() {
		super();
	}

	public Employee(int id, String name, double basicSalary) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		
	}

	double computeAllowance()
	{
		return this.basicSalary*0.35;
	}
	
	double computeTax()
	{
		return this.basicSalary*0.10;
	}
	double getNetSalary()
	{
		return this.basicSalary+this.computeAllowance()-this.computeTax();
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", basicSalary=" + basicSalary + "]";
	}
	
}
