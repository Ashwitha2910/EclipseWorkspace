
public class Client4 {

	public static void main(String[] args) {
//		Object count=new Object();
		int count=0,scount=0,ecount=0,mcount=0,rcount=0,secount=0,ccount=0;
        Object []arr=new Object[10];
        arr[0]=new Circle(5);
        arr[1]=new Student(56,75);
        arr[2]=new Employee(101,"john",20000.00);
        arr[3]=new Manager(102,"Peter",30000.00,25);
        arr[4]=new SalesEmployee(102,"Sam",40000.00,"Jammu");
        arr[5]=new RegionalManager(104,"Ashwitha",100000.0, 500,"Puttur");
        arr[6]=new CollegeStudent(88,67,"Sahyadri College");
        arr[7]=new Manager(102,"Akhil",60000.00,25);
        arr[8]=new Circle(7);

        
      //instanceof:to check whether a instance pointing to the object
        System.out.println(arr[0] instanceof Circle);
        System.out.println(arr[3] instanceof Object);
        
        for(Object obj:arr)
        {
        	if(obj instanceof Circle) {
        	Circle temp=(Circle)obj;
        	System.out.println("Circle radius: "+temp.rad);
        	count+=1;
//        	System.out.println("Total Circles: "+temp.count);
        }
        	if(obj instanceof Student)
        	{
        		Student temp=(Student)obj;
        		System.out.println("Total Marks: "+temp.getTotal());
        		scount++;
//            	System.out.println("Total students: "+temp.count);
        	}
        	if(obj instanceof Employee)
        	{
        		Employee temp=(Employee)obj;
        		System.out.println("Employee Salary :"+temp.getNetSalary());
        		ecount+=1;
//            	System.out.println("Total students: "+temp.count);
        	}
        	if(obj instanceof SalesEmployee)
        	{
        		SalesEmployee temp=(SalesEmployee)obj;
        		System.out.println(temp.getAreaName());
        		secount+=1;
//            	System.out.println("Total students: "+temp.count);
        	}
        	if(obj instanceof Manager)
        	{
        		Manager temp=(Manager)obj;
        		System.out.println("Employee Count :"+temp.getEmpCount());
        		mcount+=1;
//            	System.out.println("Total Managers: "+temp.count);
        	}
       
        	
        	if(obj instanceof RegionalManager)
        	{
        		RegionalManager temp=(RegionalManager)obj;
        		System.out.println(temp.getRegionName());
        		System.out.println(temp.getEmpCount());
        		System.out.println(temp.basicSalary);
        		System.out.println(temp.id);
        		rcount+=1;
//            	System.out.println("Total Regional Managers: "+temp.count);
        	}
        	if(obj instanceof CollegeStudent)
        	{
        		CollegeStudent temp=(CollegeStudent)obj;
        		System.out.println("Mark 1: "+temp.mark1);
        		System.out.println("Mark 2: "+temp.mark2);
        		System.out.println("College Address"+temp.getCollegeAddress());
        		ccount+=1;
//            	System.out.println("Total Colleges: "+temp.count);

        	}
        }
        System.out.println("Total Managers"+mcount);
        System.out.println("Total Employees"+ecount);
        System.out.println("Total Colleges"+ccount);
        System.out.println("Total SalesEmployees"+secount);
        System.out.println("Total Students"+scount);
        System.out.println("Total RegionalManagers"+rcount);
        System.out.println("Total circles"+count);
 double max=0;
        for(Object a:arr)
        {
        	if(a instanceof Employee)
        	{
        		Employee abc=(Employee)a;
        		if(max<abc.basicSalary)
        		{
        			max=abc.basicSalary;
        		}
        	}
        }
        System.out.println("Highest salary is :"+max);
}
}

