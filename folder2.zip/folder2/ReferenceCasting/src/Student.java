
public class Student {
	int mark1,mark2;
	int scount=0;
	public Student() {
		super();
	}

	public Student(int mark1, int mark2) {
		super();
		this.mark1 = mark1;
		this.mark2 = mark2;
	}

	int getTotal()
	{
		return this.mark1+this.mark2;
	}

	@Override
	public String toString() {
		return "Student [mark1=" + mark1 + ", mark2=" + mark2 + "]";
	}
	
}
