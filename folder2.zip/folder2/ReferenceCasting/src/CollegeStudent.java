
public class CollegeStudent extends Student {
	String collegeAddress;
	int ccount=0;

	public CollegeStudent(int mark1, int mark2, String collegeAddress) {
		super(mark1, mark2);
		this.collegeAddress = collegeAddress;
	}

	public CollegeStudent() {
		super();
	}

	public String getCollegeAddress() {
		return collegeAddress;
	}

	public void setCollegeAddress(String collegeAddress) {
		this.collegeAddress = collegeAddress;
	}
	
	
	
}
