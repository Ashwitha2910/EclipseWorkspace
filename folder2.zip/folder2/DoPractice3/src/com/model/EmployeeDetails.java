package com.model;

public class EmployeeDetails {
	private int id;
	private String empName;
	private String eAddress;
	private int eAge;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String geteAddress() {
		return eAddress;
	}
	public void seteAddress(String eAddress) {
		this.eAddress = eAddress;
	}
	public int geteAge() {
		return eAge;
	}
	public void seteAge(int eAge) {
		this.eAge = eAge;
	}
	public EmployeeDetails(int id, String empName, String eAddress, int eAge) {
		super();
		this.id = id;
		this.empName = empName;
		this.eAddress = eAddress;
		this.eAge = eAge;
	}
	public EmployeeDetails() {
		super();
	}
	@Override
	public String toString() {
		return "EmployeeDetails [id=" + id + ", empName=" + empName + ", eAddress=" + eAddress + ", eAge=" + eAge + "]";
	}
	
	
}
