package com.view;

import com.controller.EmployeeDao;

public class MainClass {

	public static void main(String[] args) {
		EmployeeDao emp=new EmployeeDao();
		System.out.println(emp.searchEmployee());

	}

}
