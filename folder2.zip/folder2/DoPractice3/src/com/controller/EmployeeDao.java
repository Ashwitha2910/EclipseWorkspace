package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.model.EmployeeDetails;

public class EmployeeDao {
	
	public List<EmployeeDetails> searchEmployee(){
	List<EmployeeDetails> list=new ArrayList<EmployeeDetails>();
    Connection con=ConnectionManager.createConnection();
    try{
    	PreparedStatement p=con.prepareStatement("select * from EmployeeDetails where eAddress='Mumbai' and eAge>32;");
    	ResultSet res=p.executeQuery();
    	while(res.next()) {
    		EmployeeDetails emp=new EmployeeDetails(res.getInt(1),res.getString(2),res.getString(3),res.getInt(4));
    		list.add(emp);
    	}
    	return list;
    }catch(Exception ex) {
		ex.printStackTrace();
		return null;
	}
	}
}
