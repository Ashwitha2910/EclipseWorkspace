package com.model;

public class Student {
	private int stId;
	private String stName;
	private int stAge;
	private String stAddress;
	public int getStId() {
		return stId;
	}
	public void setStId(int stId) {
		this.stId = stId;
	}
	public String getStName() {
		return stName;
	}
	public void setStName(String stName) {
		this.stName = stName;
	}
	public int getStAge() {
		return stAge;
	}
	public void setStAge(int stAge) {
		this.stAge = stAge;
	}
	public String getStAddress() {
		return stAddress;
	}
	public void setStAddress(String stAddress) {
		this.stAddress = stAddress;
	}
	public Student(int stId, String stName, int stAge, String stAddress) {
		super();
		this.stId = stId;
		this.stName = stName;
		this.stAge = stAge;
		this.stAddress = stAddress;
	}
	public Student() {
		super();
	}
	@Override
	public String toString() {
		return "Student [stId=" + stId + ", stName=" + stName + ", stAge=" + stAge + ", stAddress=" + stAddress + "]";
	}
	
	
}
