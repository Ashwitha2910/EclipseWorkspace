
public class Assignment1 {

	public static void main(String[] args) {
		//Widening conversion
		byte a=10;
		int b= a+190;
		System.out.println("Widening Conversion");
		System.out.println(a);
		System.out.println(b);
		
		//Narrow Conversion
		double c=600.123;
		int d=(int)c;
		System.out.println("Narrow Conversion");
		System.out.println(c);
		System.out.println(d);
		
		

	}

}
