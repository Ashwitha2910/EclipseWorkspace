
public class Main1 {

	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//byte=1 byte
//short=2 byte
//int=4bytes
//long=8 byte
//
//char=2bytes
//double=8bytes 64bits
//boolean=1byte
//float=2bytes
		
byte v1=121;//-127->127
byte v2=127;
byte v3=-127;
short v4=11500;

System.out.println(v1);
System.out.println(v2);

byte a=90;
int b=a+100;
long c=b+1000;
double d=c+10.0F;
int e=(int)d;

System.out.println(a);
System.out.println(b);
System.out.println(c);
System.out.println(d);
System.out.println(e);

	}

}
