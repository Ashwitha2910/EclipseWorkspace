
public class Main2 {

	public static void main(String[] args) {
		byte v1=100;
		short v2=1000;
		int v3=10000;
		long v4=20000;
		char v5='G';
		float v6=350.F;
		double v7=450.0;
		boolean v8=true;
		   final byte x1 = 10;
		   final byte x2 = 20;
		   final byte x3 = 100;




          switch(v1) {



          case x1:
               System.out.println("xxxx");
               break;
           case x2:
               System.out.println("yyyy");
               break;
           case x3:
               System.out.println("zzzz");
               break;
		
//		final long v4=100L;
//		System.out.println(v1);
//		System.out.println(v2);
//		System.out.println(v3);
//		System.out.println(v4);

          }}}


