package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Exam;
import com.citius.bean.Student;
import com.citius.db.AdminDAO;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;

public class UpdateStudent extends Action{

	@Override
	public void init() {
		System.out.println("Updating Student...");
		System.out.println("-------------------");		
	}

	@Override
	public void execute() {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter Student Id to update:");
	     int st_id=sc.nextInt();
	     
	     System.out.println("Enter Student first name to update:");
	     String st_fname=sc.next();
	     
	     System.out.println("Enter Student last name to update:");
	     String st_lname=sc.next();
	     
	     System.out.println("Enter Student gender to update:");
	     String st_gender=sc.next();
	     
	     System.out.println("Enter Student password to update:");
	     String st_pw=sc.next();
	     
	     System.out.println("Enter Student Address to update:");
	     String st_address=sc.next();
	     
	     System.out.println("Enter Student email to update:");
	     String st_email=sc.next();
	     
	     System.out.println("Enter Student course to update:");
	     String st_course=sc.next();
	     
	     Student s=new Student(st_id,st_fname,st_lname,st_gender,st_pw,st_address,st_email,st_course);
	      Connection con=ConnectionManager.createConnection();
	      AdminDAO dao=new AdminDAOImpl();
	      System.out.println(dao.updateStudent(con, s));

	}

}
