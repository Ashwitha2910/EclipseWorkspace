package com.citius.ui;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.citius.bean.ReportCard;
import com.citius.bean.Student;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;
import com.citius.db.StudentDAOImpl;

public class GetQuestionsById extends Action{

	public static int examId;

	@Override
	public void init() {
		System.out.println("Getting Questions ");
		System.out.println("--------------------");
		
	}

	@Override
	public void execute() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter exam id ");
		examId = sc.nextInt();

		Connection con = ConnectionManager.createConnection();
		AdminDAOImpl ad = new AdminDAOImpl();

		Integer correctAnswers = ad.getQuestionById(con);
		

		if (correctAnswers == null) {
			System.out.println("no questions found");
		} else {
			List<ReportCard> list= ad.getAllReports(con);
			List<Integer> reportId = new ArrayList<Integer>();
			
			for(int i=0; i<list.size();i++) {
				reportId.add(i, list.get(i).getStud_roll_no()); 
			}
			
			Student s=new Student();
			if (!(reportId.contains(StudentDAOImpl.st_rollno))) {
				ad.insertStudentReportCard(con, 0);
			}
			Connection con2 = ConnectionManager.createConnection();
			List<ReportCard> list1 = ad.singleStudentReportCard(con2,StudentDAOImpl.st_rollno);
			ReportCard obj1 = list1.get(0);
			int reportCardId = obj1.getReportCard();
//		System.out.println("correct answers = "+ correctAnswers);
			int score = ad.UpdateStdReportScore(con, correctAnswers.intValue());

			ad.insertUpdateStudentReportCard(con, score, reportCardId);
		}
		MenuHandler3 std = new MenuHandler3();
		std.handleMenu();
	}
	}

