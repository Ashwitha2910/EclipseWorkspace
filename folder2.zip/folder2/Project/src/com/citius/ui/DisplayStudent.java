package com.citius.ui;

import java.sql.Connection;

import com.citius.db.AdminDAO;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;

public class DisplayStudent extends Action {

	@Override
	public void init() {
		System.out.println("Displaying list of Students...");
		System.out.println("-------------------------------");
		
	}

	@Override
	public void execute() {
		Connection con=ConnectionManager.createConnection();
        AdminDAO dao=new AdminDAOImpl();
        System.out.println(dao.getAllStudent(con));
        ConnectionManager.closeConnection(con);
		
	}

}
