package com.citius.ui;

public abstract class Action {
    public abstract void init();
    public abstract void execute();
    public final void go() {
        init();
        execute();
    }
}