package com.citius.ui;

import java.util.Scanner;

import com.citius.db.AdminDAOImpl;
import com.citius.db.StudentDAOImpl;

public class MenuHandler {
	public void displayMenu() {
        String[] mItems= {
                "Admin",
                "Student",
                "Exit"
        };

        for(int i=0;i<mItems.length;i++) {
            System.out.println((i+1)+"."+mItems[i]);
        }
    }
	
	public int promptForChoice() {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your choice:");
        int ch=sc.nextInt();
        return ch;
    }

	 public void handleMenu() {
	        while(true) {
	            this.displayMenu();
	            int ch=this.promptForChoice();
	            AdminDAOImpl impl=new AdminDAOImpl();
	            StudentDAOImpl st=new StudentDAOImpl();
	            switch(ch) {
	            case 1: impl.validation();
	                break;
	            case 2: st.studentValidation();
	            	break;
	            case 3:System.exit(0);
	            }
	        }

	    }
}
