package com.citius.ui;

import java.sql.Connection;

import com.citius.db.AdminDAO;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;

public class DisplayAllReports extends Action {
	@Override
	public void init() {
		System.out.println("Displaying All Reports ...");
		System.out.println("----------------------------");
		
	}

	@Override
	public void execute() {
		 Connection con=ConnectionManager.createConnection();
	        AdminDAO dao=new AdminDAOImpl();
	        System.out.println(dao.getAllReports(con));
	        ConnectionManager.closeConnection(con);
}}
