package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Questions;
import com.citius.db.AdminDAO;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;

public class DeleteQuestion extends Action {

	@Override
	public void init() {
		System.out.println("Deleteing Exam...");
		System.out.println("---------------");
		
	}

	@Override
	public void execute() {

        Scanner sc=new Scanner(System.in);

        System.out.println("Enter question ID to remove:");
        int id=sc.nextInt();

        Questions e=new Questions(id);
        Connection con=ConnectionManager.createConnection();
        AdminDAO dao=new AdminDAOImpl();
//        System.out.println(dao.displayQuestion(con, e));
        if(dao.deleteQuestion(con, e)==true)
            System.out.println("Question Removed");
        else
            System.out.println("Question Not Removed");

    
	}
}
