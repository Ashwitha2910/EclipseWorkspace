package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Questions;
import com.citius.db.AdminDAO;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;

public class AddQuestion extends Action{
	@Override
	public void init() {
		System.out.println("Adding Question...");
		System.out.println("---------------");
		
	}

	@Override
	public void execute() {

        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Question ID:");
        int q_id=sc.nextInt();
        
        System.out.println("Enter Exam id:");
        int ex_id=sc.nextInt();
        
        sc.nextLine();

        System.out.println("Enter question:");
        String que=sc.nextLine();

        System.out.println("Enter option 1:");
        String op1=sc.nextLine();
        
        System.out.println("Enter option 2:");
        String op2=sc.nextLine();
        
        System.out.println("Enter option 3:");
        String op3=sc.nextLine();
        
        System.out.println("Enter Correct Answer:");
        String ca=sc.nextLine();
        
        Questions e=new Questions(q_id,que,ex_id,op1,op2,op3,ca);
        Connection con=ConnectionManager.createConnection();
        AdminDAO dao=new AdminDAOImpl();
        if(dao.addQuestion(con, e)==true)
            System.out.println("Question Added");
        else
            System.out.println("Qquestion not Added");

    
		
	}
}
