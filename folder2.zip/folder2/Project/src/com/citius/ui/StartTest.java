package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Questions;
import com.citius.db.ConnectionManager;
import com.citius.db.StudentDAO;
import com.citius.db.StudentDAOImpl;

public class StartTest extends Action{

	@Override
	public void init() {
		System.out.println("---------------------------------");
		System.out.println("        Starting Test     ");
		System.out.println("---------------------------------");
		
	}

	@Override
	public void execute() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your roll number: ");
		int roll_no=sc.nextInt();
		
		System.out.println("Enter Exam id: ");
		int ex_id=sc.nextInt();
		
		Questions q=new Questions();
		Connection con=ConnectionManager.createConnection();
		StudentDAO dao=new StudentDAOImpl();
		System.out.println();
		
	}

}
