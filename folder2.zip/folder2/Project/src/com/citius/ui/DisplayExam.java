package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Exam;
import com.citius.db.AdminDAO;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;


public class DisplayExam extends Action{

	@Override
	public void init() {
		System.out.println("Displaying the Exam ...");
		System.out.println("------------------------");
		
	}

	@Override
	public void execute() {
		 Scanner sc=new Scanner(System.in);

	        System.out.println("Enter exam ID to search:");
	        int id=sc.nextInt();

	        Exam e=new Exam(id);
	        Connection con=ConnectionManager.createConnection();
	        AdminDAO dao=new AdminDAOImpl();
	        System.out.println(dao.displayExam(con, e));
		
	}

}
