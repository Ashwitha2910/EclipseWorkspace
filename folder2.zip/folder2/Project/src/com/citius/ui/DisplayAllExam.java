package com.citius.ui;

import java.sql.Connection;
import java.util.Iterator;
import java.util.List;

import com.citius.bean.Exam;
import com.citius.db.AdminDAO;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;


public class DisplayAllExam extends Action{

	@Override
	public void init() {
		System.out.println("Displaying the list of Exams ...");
		System.out.println("--------------------------------");
		
	}

	@Override
	public void execute() {
		 Connection con=ConnectionManager.createConnection();
	        AdminDAO dao=new AdminDAOImpl();
	        
	        
	      List<Exam> list=dao.getAllExam(con);
//	      Iterator<Exam> itr=list.iterator();
	      for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			Exam exam = (Exam) iterator.next();
			System.out.println(exam.getE_name());
		}
	        ConnectionManager.closeConnection(con);
		
	}

}
