package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Student;
import com.citius.db.AdminDAO;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;

public class InsertStudent extends Action{

	@Override
	public void init() {
		System.out.println("Adding Student...");
		System.out.println("-----------------");
		
	}

	@Override
	public void execute() {
		Scanner sc=new Scanner(System.in);
//        System.out.println("Enter Student ID:");
//        int s_id=sc.nextInt();

        System.out.println("Enter Student First Name:");
        String s_fname=sc.next();

        System.out.println("Enter Student Last name:");
        String s_Lname=sc.next();

        System.out.println("Enter gender:");
        String gender=sc.next();
        
        System.out.println("Enter Student password:");
        String s_password=sc.next();
        
        System.out.println("Enter address:");
        String s_address=sc.next();
        
        System.out.println("Enter email:");
        String s_email=sc.next();
        
        System.out.println("Enter Course:");
        String s_course=sc.next();
        
        Student e=new Student(s_fname,s_Lname,gender,s_password,s_address,s_email,s_course);
        Connection con=ConnectionManager.createConnection();
        AdminDAO dao=new AdminDAOImpl();
        if(dao.addStudent(con, e)==true)
            System.out.println("Student Added");
        else
            System.out.println("Student not Added");
		
	}

}
