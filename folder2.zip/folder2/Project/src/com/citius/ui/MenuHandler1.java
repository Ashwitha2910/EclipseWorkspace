package com.citius.ui;

import java.util.Scanner;

public class MenuHandler1 {
	  public void displayMenu() {
	        String[] mItems= {
	                "Add Exam",
	                "Remove Exam",
	                "Update Exam",
	                "Search Exam",
	                "List all Exams",
	                "Add Student",
	                "Delete Student",
	                "Update Student",
	                "Search Student",
	                "Display Students",
	                "Add Question",
	                "Delete Question",
	                "Update a Question",
	                "Display All questions",
	                "Search Report card",
	                "Display All reports",
	                "Exit"
	        };

	        for(int i=0;i<mItems.length;i++) {
	            System.out.println((i+1)+"."+mItems[i]);
	        }
	    }

	    public int promptForChoice() {
	        Scanner sc=new Scanner(System.in);
	        System.out.println("Enter your choice:");
	        int ch=sc.nextInt();
	        return ch;
	    }

	    public void handleMenu() {
	        while(true) {
	            this.displayMenu();
	            int ch=this.promptForChoice();

	            Action ac=null;

	            switch(ch) {
	            case 1:
	                ac=new AddExam();
	                ac.go();
	                break;
	            case 2:
	                ac=new DeleteExam();
	                ac.go();
	                break;
	            case 3:
	                ac= new UpdateExam();
	                ac.go();
	                break;
	            case 4:
	                ac=(Action) new DisplayExam();
	                ac.go();
	                break;
	            case 5 :
	                ac=new DisplayAllExam();
	                ac.go();
	                break;
	            case 6 :
	                ac=new InsertStudent();
	                ac.go();
	                break;
	            case 7:
	                ac=new DeleteStudent();
	                ac.go();
	                break;
	            case 8:
	                ac=new UpdateStudent();
	                ac.go();
	                break;
	            case 9 :
	                ac=new SearchStudent();
	                ac.go();
	                break;
	            case 10 :
	                ac=new DisplayStudent();
	                ac.go();
	                break;  
	            case 11:
	                ac=new AddQuestion();
	                ac.go();
	                break; 
	            case 12 :
	                ac=new DeleteQuestion();
	                ac.go();
	                break; 
	            case 13 :
	                ac=new UpdateQuestion();
	                ac.go();
	                break;   
	            case 14 :
	                ac=new DisplayQuestions();
	                ac.go();
	                break;
	            case 15 :
	                ac=new SearchReport();
	                ac.go();
	                break;
	            case 16 :
	                ac=new DisplayAllReports();
	                ac.go();
	                break;
	            case 17:MenuHandler m=new MenuHandler();
	            		m.handleMenu();
	            		break;
	            }
	        }

	    }
}
