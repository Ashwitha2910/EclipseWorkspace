package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Exam;
import com.citius.db.ConnectionManager;
import com.citius.db.AdminDAOImpl;
import com.citius.db.AdminDAO;
public class DeleteExam extends Action {

	@Override
	public void init() {
		System.out.println("Deleteing Exam...");
		System.out.println("---------------");
		
	}

	@Override
	public void execute() {

        Scanner sc=new Scanner(System.in);

        System.out.println("Enter exam ID to remove:");
        int id=sc.nextInt();

        Exam e=new Exam(id);
        Connection con=ConnectionManager.createConnection();
        AdminDAO dao=new AdminDAOImpl();
        System.out.println(dao.displayExam(con, e));
        if(dao.deleteExam(con, e)==true)
            System.out.println("Exam Removed");
        else
            System.out.println("Exam Not Removed");

    
		
	}

}
