package com.citius.ui;

import java.util.Scanner;

import com.citius.db.StudentDAOImpl;

public class MenuHandler3 {
	public void displayMenu() {
		
        String[] mItems= {
                "Go For Test",
                "See Report Card",
                "Exit"
        };

        for(int i=0;i<mItems.length;i++) {
            System.out.println((i+1)+"."+mItems[i]);
        }
    }
	
	public int promptForChoice() {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your choice:");
        int ch=sc.nextInt();
        return ch;
    }
	
	 public void handleMenu() {
		 System.out.println("*****************************************");
	        while(true) {
	            this.displayMenu();
	            int ch=this.promptForChoice();
	            
	            Action ac=null;
	            switch(ch) {
	            case 1: GetQuestionsById g=new GetQuestionsById();
	            		g.init();
	            		g.execute();
	                break;
	            case 2:ac=new SearchReport();
	            		ac.go();
	                 break;            
	            case 3:MenuHandler m=new MenuHandler();
	            		m.handleMenu();
	            		break;
	            }
	        }

	    }
}
