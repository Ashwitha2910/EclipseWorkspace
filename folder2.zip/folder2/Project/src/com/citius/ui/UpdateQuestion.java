package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Exam;
import com.citius.bean.Questions;
import com.citius.db.AdminDAO;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;

public class UpdateQuestion extends Action{

	@Override
	public void init() {
		System.out.println("Updating Question..");
		System.out.println("--------------------");
		
	}

	@Override
	public void execute() {
		Scanner sc=new Scanner(System.in);
        
	      System.out.println("Enter question id to update:");
	      int q_id=sc.nextInt();
	      
	      System.out.println("Enter question update:");
	      String que=sc.next();
	      System.out.println("Enter exam id:");
	      int e_id=sc.nextInt();
	      System.out.println("Enter new option 1:");
	      String o1=sc.next();
	      System.out.println("Enter new option 2:");
	      String o2=sc.next();
	      System.out.println("Enter new option 3:");
	      String o3=sc.next();
	      System.out.println("Enter new correct answer:");
	      String ca=sc.next();
	      
	      Questions e=new Questions(q_id,que,e_id,o1,o2,o3,ca);
	      Connection con=ConnectionManager.createConnection();
	      AdminDAO dao=new AdminDAOImpl();
	      System.out.println(dao.updateQuestion(con, e));
		
	}

}
