package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Student;
import com.citius.db.AdminDAO;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;

public class SearchStudent extends Action {

	@Override
	public void init() {
		System.out.println("Searching Student...");
		System.out.println("---------------------");
		
	}

	@Override
	public void execute() {
		 Scanner sc=new Scanner(System.in);

	        System.out.println("Enter Student ID to search:");
	        int id=sc.nextInt();

	        Student e=new Student(id);
	        Connection con=ConnectionManager.createConnection();
	        AdminDAO dao=new AdminDAOImpl();
	        System.out.println(dao.displayStudent(con, e));
		
	}

}
