package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Exam;
import com.citius.db.AdminDAO;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;

public class UpdateExam extends Action{

	@Override
	public void init() {
		System.out.println("Updating Customer details..");
		System.out.println("----------------------------");
		
	}

	@Override
	public void execute() {
		Scanner sc=new Scanner(System.in);
            
      System.out.println("Enter new Exam name:");
      String e_name=sc.next();
      
      System.out.println("Enter new Admin name:");
      String a_name=sc.next();
      
      System.out.println("Enter new Subject name:");
      String s_name=sc.next();
      
      System.out.println("Enter new description:");
      String desc=sc.next();
      
      System.out.println("Enter Exam ID:");
      int e_id=sc.nextInt();
      
      Exam e=new Exam(e_id,e_name,a_name,s_name,desc);
      Connection con=ConnectionManager.createConnection();
      AdminDAO dao=new AdminDAOImpl();
      System.out.println(dao.updateExam(con, e));
	}

}
