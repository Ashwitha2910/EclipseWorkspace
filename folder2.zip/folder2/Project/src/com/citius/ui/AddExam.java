package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Exam;
import com.citius.db.AdminDAO;
import com.citius.db.AdminDAOImpl;
import com.citius.db.ConnectionManager;


public class AddExam extends Action{

	@Override
	public void init() {
		System.out.println("Adding Exam...");
		System.out.println("---------------");
		
	}

	@Override
	public void execute() {

        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter Exam ID:");
//        int e_id=sc.nextInt();

        System.out.println("Enter Exam Name:");
        String e_name=sc.next();

        System.out.println("Enter admin name:");
        String created_by=sc.next();

        System.out.println("Enter subject name:");
        String subject=sc.next();
        
        System.out.println("Enter Description of exam:");
        String desc=sc.next();
        
        Exam e=new Exam(e_name,created_by,subject,desc);
        Connection con=ConnectionManager.createConnection();
        AdminDAO dao=new AdminDAOImpl();
        if(dao.addExam(con, e)==true)
            System.out.println("Exam Added");
        else
            System.out.println("Exam not Added");

    
		
	}

	
}
