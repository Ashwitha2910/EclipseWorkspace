package com.citius.ui;

public class Test extends Action{

	@Override
	public void init() {
		System.out.println("Starting test..");
		System.out.println("=================");
		
	}

	@Override
	public void execute() {
		
		
	}

}
