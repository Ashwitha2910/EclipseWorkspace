package com.citius.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.citius.bean.Admin;
import com.citius.bean.Exam;
import com.citius.bean.Questions;
import com.citius.bean.ReportCard;
import com.citius.bean.Student;
import com.citius.ui.GetQuestionsById;
import com.citius.ui.MenuHandler1;

public class AdminDAOImpl implements AdminDAO {
	
	
	@Override
	public boolean addExam(Connection con, Exam e) {
		 boolean result=false;
	        try {
	        PreparedStatement st=con.prepareStatement(INSERT_EXAM);
//	        st.setInt(1,e.getE_id());
	        st.setString(1,e.getE_name());
	        st.setString(2,e.getCreated_by());
	        st.setString(3,e.getSubject());
	        st.setString(4,e.getDescription());

	        int r=st.executeUpdate();
	        if(r==1)
	            result=true;
	        }catch(Exception ex) {
	            ex.printStackTrace();
	            result = false;
	        }
	        return result;
	        
	}

	@Override
	public boolean updateExam(Connection con, Exam e) {
		boolean result=false;
		try {
	          PreparedStatement st=con.prepareStatement(UPDATE_EXAM);
	          st.setString(1,e.getE_name());
	          st.setString(2,e.getCreated_by());
	          st.setString(3,e.getSubject());
	          st.setString(4,e.getDescription());
	          st.setInt(5,e.getE_id());

	          int rs=st.executeUpdate();
	          if(rs==1) {
	        	  result=true;
	          }
	      }catch(Exception ex) {
	          ex.printStackTrace();
	      }        
		return result;
	}

	@Override
	public boolean deleteExam(Connection con, Exam e) {
		 boolean result=false;
	        try {
	            PreparedStatement st=con.prepareStatement(DELETE_EXAM);
	            st.setInt(1,e.getE_id());
	            int r=st.executeUpdate();
	            if(r==1)
	                result=true;
	            }catch(Exception ex) {
	                ex.printStackTrace();
	            }
	        return result;
	}

	public Exam displayExam(Connection con, Exam e) {
		Exam xm=null;
      try {
          PreparedStatement st=con.prepareStatement(DISPLAY_EXAM);
          st.setInt(1,e.getE_id());

          ResultSet rs=st.executeQuery();
          if(rs.next()) {
              xm=new Exam(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
          }
      }catch(Exception ex) {
          ex.printStackTrace();
      }        
      return xm;
	}

	@Override
	public List<Exam> getAllExam(Connection con) {
		List <Exam> allExm=new ArrayList<Exam>();
        try {
            PreparedStatement st=con.prepareStatement(DISPLAY_ALL_EXAM);

            ResultSet rs=st.executeQuery();

            while(rs.next()) {
                Exam exm=new Exam(rs.getInt(1), rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
                allExm.add(exm);
            }
        }catch(Exception ex) {
            ex.printStackTrace();
        }
        return allExm;
	}

	@Override
	public boolean addStudent(Connection con, Student s) {
		 boolean result=false;
	        try {
	        PreparedStatement st=con.prepareStatement(INSERT_STUDENT);
//	        st.setInt(1,s.getSt_id());
	        st.setString(1,s.getF_name());
	        st.setString(2,s.getL_name());
	        st.setString(3,s.getGender());
	        st.setString(4,s.getSt_password());
	        st.setString(5,s.getAddress());
	        st.setString(6,s.getEmail());
	        st.setString(7,s.getCourse());

	        int r=st.executeUpdate();
	        if(r==1)
	            result=true;
	        }catch(Exception ex) {
	            ex.printStackTrace();
	        }
	        return result;
	}

	@Override
	public boolean updateStudent(Connection con, Student s) {
		boolean result=false;
		try {
			PreparedStatement st=con.prepareStatement(UPDATE_STUDENT);
			st.setString(1, s.getF_name());
			st.setString(2, s.getL_name());
			st.setString(3, s.getGender());
			st.setString(4, s.getSt_password());
			st.setString(5, s.getAddress());
			st.setString(6, s.getEmail());
			st.setString(7, s.getCourse());
			st.setInt(8, s.getSt_id());
			int r=st.executeUpdate();
			if(r==1)
				result=true;
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return result;
	}

	@Override
	public boolean deleteStudent(Connection con, Student s) {
		boolean result=false;
        try {
            PreparedStatement st=con.prepareStatement(DELETE_STUDENT);
            st.setInt(1,s.getSt_id());
            int r=st.executeUpdate();
            if(r==1)
                result=true;
            }catch(Exception ex) {
                ex.printStackTrace();
            }
        return result;
	}

	@Override
	public Student displayStudent(Connection con, Student s) {
		Student std=null;
	      try {
	          PreparedStatement st=con.prepareStatement(DISPLAY_STUDENT);
	          st.setInt(1,s.getSt_id());

	          ResultSet rs=st.executeQuery();
	          if(rs.next()) {
	              std=new Student(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
	          }
	      }catch(Exception ex) {
	          ex.printStackTrace();
	      }        
	      return std;
	}

	@Override
	public List<Student> getAllStudent(Connection con) {
		List <Student> allst=new ArrayList<Student>();
        try {
            PreparedStatement st=con.prepareStatement(DISPLAY_ALL_STUDENT);

            ResultSet rs=st.executeQuery();

            while(rs.next()) {
                Student stud=new Student(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
                allst.add(stud);
            }
        }catch(Exception ex) {
            ex.printStackTrace();
        }
        return allst;
	}

	@Override
	public boolean addQuestion(Connection con, Questions s) {
		boolean result=false;
        try {
        PreparedStatement st=con.prepareStatement(INSERT_QUESTION);
        st.setInt(1,s.getQ_id());
        st.setString(2,s.getQue());
        st.setInt(3,s.getExam_id());
        st.setString(4,s.getOpt1());
        st.setString(5,s.getOpt2());
        st.setString(6,s.getOpt3());
        st.setString(7,s.getCorrect_ans());
     
        int r=st.executeUpdate();
        if(r==1)
            result=true;
        }catch(Exception ex) {
            ex.printStackTrace();
        }
        return result;
	}

	@Override
	public boolean updateQuestion(Connection con, Questions s) {
		boolean result=false;
		try {
			PreparedStatement st=con.prepareStatement(UPDATE_QUESTION);
			st.setString(1, s.getQue());
			st.setInt(2, s.getExam_id());
			st.setString(3, s.getOpt1());
			st.setString(4, s.getOpt2());
			st.setString(5, s.getOpt3());
			st.setString(6, s.getCorrect_ans());
			st.setInt(7, s.getQ_id());
			int r=st.executeUpdate();
			if(r==1)
				result=true;
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return result;
	}

	@Override
	public boolean deleteQuestion(Connection con, Questions s) {
		boolean result=false;
        try {
            PreparedStatement st=con.prepareStatement(DELETE_QUESTION);
            st.setInt(1,s.getQ_id());
            int r=st.executeUpdate();
            if(r==1)
                result=true;
            }catch(Exception ex) {
                ex.printStackTrace();
            }
        return result;
	}

	@Override
	public List<Questions> getAllQuestion(Connection con) {
		List <Questions> allQ=new ArrayList<Questions>();
        try {
            PreparedStatement st=con.prepareStatement(DISPLAY_ALL_QUESTION);
            ResultSet rs=st.executeQuery();

            while(rs.next()) {
                Questions qn=new Questions(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
                allQ.add(qn);
            }
        }catch(Exception ex) {
            ex.printStackTrace();
        }
        return allQ;
	}

	@Override
	public ReportCard searchReportCard(Connection con, ReportCard s) {
		ReportCard rc=null;
	      try {
	          PreparedStatement st=con.prepareStatement(DISPLAY_REPORTCARD);
	          st.setInt(1,s.getStud_roll_no());

	          ResultSet rs=st.executeQuery();
	          if(rs.next()) {
	              rc=new ReportCard(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4));
	          }
	      }catch(Exception ex) {
	          ex.printStackTrace();
	      }        
	      return rc;
	}

	@Override
	public List<ReportCard> getAllReports(Connection con) {
		List <ReportCard> allRc=new ArrayList<ReportCard>();
        try {
            PreparedStatement st=con.prepareStatement(DISPLAY_ALL_REPORTCARD);

            ResultSet rs=st.executeQuery();

            while(rs.next()) {
            	ReportCard qn=new ReportCard(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4));
                allRc.add(qn);
            }
        }catch(Exception ex) {
            ex.printStackTrace();
        }
        return allRc;
	}

	@Override
	public void validation() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Admin id: ");
		int id=sc.nextInt();
	
		System.out.println("Enter Username: ");
		String un=sc.next();
		
		System.out.println("Enter Password: ");
		String pw=sc.next();
		Connection con= ConnectionManager.createConnection();
		Admin a=new Admin();
		try {
            PreparedStatement st=con.prepareStatement(VALIDATE);
            ResultSet rs=st.executeQuery();
            if(rs.next()) {
                 int ad_id=(rs.getInt("admin_id"));
	             String ad_un=rs.getString("username");
	             String ad_pw=rs.getString("password");
	             
	             if(id==ad_id && un.equals(ad_un)  && pw.equals(ad_pw)) {
	 				MenuHandler1 admin = new MenuHandler1();
	 				admin.handleMenu();

	          }
	             
            }      	
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
	}

	@Override
	public Integer searchQuestions(Connection con,Questions q) {

//		List <Questions> qsn=new ArrayList<Questions>();
//	      try {
//	          PreparedStatement st=con.prepareStatement(SEARCH_QUESTION_BY_EXAM_ID);
//	          st.setInt(1,s.getExam_id());
//
//	          ResultSet rs=st.executeQuery();
//	          if(rs.next()) {
//	             Questions q=new Questions(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
//	             qsn.add(q);
//	          }
//	      }catch(Exception ex) {
//	          ex.printStackTrace();
//	      }        
//	      System.out.println(qsn);
//		return qsn;
		
		Integer correctAnswers = 0;
		Questions ques = new Questions();
//		String query = "select * from Exam.QuestionTable where examID = ?";
		try {
			PreparedStatement st = con.prepareStatement(SEARCH_QUESTION_BY_EXAM_ID);
			st.setInt(1,q.getExam_id());
			ResultSet rs = st.executeQuery();

			if (rs.next()) {

				do {

					ques.setQue(rs.getString(2));
					ques.setOpt1(rs.getString(4));
					ques.setOpt2(rs.getString(5));
					ques.setOpt3(rs.getString(6));

					System.out.println("\nQuestion \n" + ques.getQue() + "\n\noption1=" + ques.getOpt1()
							+ "\noption2=" + ques.getOpt2() + "\noption3=" + ques.getOpt3() + "\n");

					Scanner sc = new Scanner(System.in);
					System.out.println("Enter the Answer");
					String answer = sc.next();
					if (answer.equals(q.getCorrect_ans())) {
						correctAnswers++;
					}

				} while (rs.next());
			}

			else {
				return null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return correctAnswers;
	}
	
	public void insertStudentReportCard(Connection con, int score) {


		String Updatequery = "insert into ReportCard values ((?),(?),GETDATE())";
//		StudentDAO d=new StudentDAOImpl()
		Student s=new Student();
		try {
			PreparedStatement st = con.prepareStatement(Updatequery);
			st.setInt(1,StudentDAOImpl.st_rollno );
			st.setInt(2, score);
			int r = st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	
	public Integer getQuestionById(Connection con) {

		Integer correctAnswers = 0;
		Questions ques = new Questions();
		String query = "select * from Questions where examID = ?";
		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, GetQuestionsById.examId);
			ResultSet rs = st.executeQuery();

			if (rs.next()) {

				do {

					ques.setQue(rs.getString(2));
					ques.setOpt1(rs.getString(4));
					ques.setOpt2(rs.getString(5));
					ques.setOpt3(rs.getString(6));

					System.out.println("\nQuestion \n" + ques.getQue() + "\n\noption1=" + ques.getOpt1()
							+ "\noption2=" + ques.getOpt2() + "\noption3=" + ques.getOpt3() + "\n");

					Scanner sc = new Scanner(System.in);
					System.out.println("Enter the Answer");
					String answer = sc.next();
					if (answer.equals(rs.getString(7))) {
						correctAnswers++;
					}

				} while (rs.next());
			}

			else {
				return null;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return correctAnswers;

	}

	public List<ReportCard> singleStudentReportCard(Connection con, int id) {
		// TODO Auto-generated method stub
		List<ReportCard> std = new ArrayList<ReportCard>();
		String query = "select * from ReportCard where studentRollNumber = ? ";
		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, id);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				ReportCard src = new ReportCard(rs.getInt(1), rs.getInt(2), rs.getInt(3),
						rs.getString(4));
				std.add(src);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return std;
	}
	
	public int UpdateStdReportScore(Connection con, int correctAnswer) {
		int rollNumber = StudentDAOImpl.st_rollno;
		int dbScore = 0;

		ReportCard obj = null;

		String getQuery = "select * from ReportCard where studentRollNumber = ?";

		List<ReportCard> stdCards = singleStudentReportCard(con, StudentDAOImpl.st_rollno);

		obj = stdCards.get(0);
		dbScore = obj.getScore() + (correctAnswer * 10);

//		 dbScore =Integer.parseInt(stdCards.get(1).toString());

		return dbScore;

	}
	
public void insertUpdateStudentReportCard(Connection con, int score, int reportCardId) {
	
		
//		if(reportId.contains(reportCardId)) {
//			insertStudentReportCard(con, score);
//		}
		

		
		String Updatequery = "update  ReportCard  set Score = ? where reportCardID = (?) ";
//		System.out.println(score);
//		System.out.println(StudentCredentials.rollNumber);

		try {
			PreparedStatement st = con.prepareStatement(Updatequery);
			st.setInt(1, score);
			st.setInt(2, reportCardId);
			int r = st.executeUpdate();
			System.out.println("Exam Finished");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		
	}
}
