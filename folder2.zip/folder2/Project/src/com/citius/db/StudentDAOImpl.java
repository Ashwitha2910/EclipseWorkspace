package com.citius.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.citius.bean.Questions;
import com.citius.ui.MenuHandler3;

public class StudentDAOImpl implements StudentDAO {
	public static int st_rollno;
	@Override
	public void studentValidation() {
		String pw=null;
		String em=null;
//		int rollno=0;
		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter your student id:");
//		rollno=sc.nextInt();
		
		System.out.println("Please enter your Registered Email id:");
		String st_email=sc.next();
		
		System.out.println("Enter your password");
		String st_pw=sc.next();
		try {
		Connection con=ConnectionManager.createConnection();
		PreparedStatement ps= con.prepareStatement("select * from Student where studentEmail=?");
		ps.setString(1,st_email);
		ResultSet rs=ps.executeQuery();
		
		while(rs.next()) {
			
			pw=rs.getString(5);
			st_rollno=rs.getInt(1);
//			em=rs.getString(7);
						
		}
		if(st_pw.equals(pw))
		{
			MenuHandler3 mh=new MenuHandler3();
			mh.handleMenu();
		}
		else
			System.out.println("Invalid email or Password..");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	@Override
	public Integer goForTest() {
		System.out.println("Fetching Questions..");
		System.out.println("----------------------");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Exam ID to search:");
		int id=sc.nextInt();
		Connection con=ConnectionManager.createConnection();
		Questions q=new Questions();
		int correctAnswers=0;
		try {
			PreparedStatement st=con.prepareStatement(GET_QUESTION_BY_EXAMID);
			st.setInt(1, q.getExam_id());
			ResultSet rs=st.executeQuery();
			if(rs.next())
			{
			do {
				q.setQue(rs.getString(2));
				q.setOpt1(rs.getString(4));
				q.setOpt2(rs.getString(5));
				q.setOpt3(rs.getString(6));
				
				System.out.println("\nQue:\n" + q.getQue() + "\n\n1=" + q.getOpt1()
				+ "\n2=" + q.getOpt2() + "\n3=" + q.getOpt3() + "\n");
				
				
				System.out.println("Enter the Answer");
				String answer = sc.next();
				if (answer.equals(rs.getString(7))) {
					correctAnswers++;
				}
			}while(rs.next());
			
			
		}
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return correctAnswers;
	}

}
