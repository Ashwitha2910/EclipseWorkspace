package com.citius.db;

public interface StudentDAO {

	String STUDENT_VALIDATION="select * from Student where studentEmail=?";
	String GET_ALL_EXAM="select * from Exam";
	String GET_QUESTION_BY_EXAMID="SELECT * FROM Questions WHERE examID=?";
	
	void studentValidation();
	Integer goForTest();
	
	
}
