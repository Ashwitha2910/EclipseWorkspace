package com.citius.db;

import java.sql.Connection;
import java.util.List;

import com.citius.bean.Admin;
import com.citius.bean.Exam;
import com.citius.bean.Questions;
import com.citius.bean.ReportCard;
import com.citius.bean.Student;

public interface AdminDAO {
	String VALIDATE="select * from Validation";
	String STUDENT_VALIDATION="select * from Student";

	
	String INSERT_EXAM="insert into Exam values(?,?,?,?);";
	String DELETE_EXAM="delete from Exam where examID=?";
	String UPDATE_EXAM="update Exam set examName=?,Created_by=?,subject=?,description=? where examID=?";
	String DISPLAY_ALL_EXAM=" select * from Exam";
	String DISPLAY_EXAM="select * from Exam where examID=?";
	
	String INSERT_STUDENT="insert into Student values(?,?,?,?,?,?,?)";
	String DELETE_STUDENT="delete from Student where studentRollNumber=?";
	String UPDATE_STUDENT="update Student set studentFirstName=?,studentLastName=?,studentGender=?,studentPassword=?,studentAddress=?,studentEmail=?,studentCourse=? where studentRollNumber=?";
	String DISPLAY_ALL_STUDENT="select * from Student";
	String DISPLAY_STUDENT="select * from Student where studentRollNumber=?";
	
	String ADD_REPORT="insert into ReportCard values(?,?,?)";
	String DISPLAY_ALL_REPORTCARD="select * from ReportCard";
	String DISPLAY_REPORTCARD="select * from ReportCard where studentRollNumber=?";
	
	String INSERT_QUESTION="insert into Questions values(?,?,?,?,?,?,?)";
	String DELETE_QUESTION="delete from Questions where q_id=?";
	String UPDATE_QUESTION="update Questions set que=?,examID=?,Opt1=?,Opt2=?,Opt3=?,Correct_ans=? where q_id=?";
	String SEARCH_QUESTION_BY_EXAM_ID="select * from Questions where examID=?";
	String DISPLAY_ALL_QUESTION="select * from Questions";
	
	void validation();
	
	 boolean addExam(Connection con,Exam e);
	 boolean updateExam(Connection con,Exam e);
	 boolean deleteExam(Connection con,Exam e);
	 Exam displayExam(Connection con,Exam e);
	 List<Exam>getAllExam(Connection con);
	 
	 boolean addStudent(Connection con,Student s);
	 boolean updateStudent(Connection con,Student s);
	 boolean deleteStudent(Connection con,Student s);
	 Student displayStudent(Connection con,Student s);
	 List<Student>getAllStudent(Connection con);
	 
	 boolean addQuestion(Connection con,Questions s);
	 boolean updateQuestion(Connection con,Questions s);
	 Integer searchQuestions(Connection con,Questions s);
	 boolean deleteQuestion(Connection con,Questions s);
	 
	 List<Questions>getAllQuestion(Connection con);
	 
//	 boolean addReport(Connection con,ReportCard r);
	 ReportCard searchReportCard(Connection con,ReportCard s);
	 List<ReportCard>getAllReports(Connection con);
}
