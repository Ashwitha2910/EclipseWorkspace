package com.citius.bean;

import java.util.Objects;

public class Student implements Comparable<Student> {
	private int st_id;
	private String f_name;
	private String l_name;
	private String gender;
	private String st_password;
	private String address;
	private String email;
	private String course;
	
	public Student() {
		super();
	}
	

	public Student(String f_name, String l_name, String gender, String st_password, String address, String email,
			String course) {
		super();
		this.f_name = f_name;
		this.l_name = l_name;
		this.gender = gender;
		this.st_password = st_password;
		this.address = address;
		this.email = email;
		this.course = course;
	}


	public Student(int st_id) {
		super();
		this.st_id = st_id;
	}


	public Student(int st_id, String f_name, String l_name, String gender, String st_password, String address,
			String email, String course) {
		super();
		this.st_id = st_id;
		this.f_name = f_name;
		this.l_name = l_name;
		this.gender = gender;
		this.st_password = st_password;
		this.address = address;
		this.email = email;
		this.course = course;
	}

	public int getSt_id() {
		return st_id;
	}

	public void setSt_id(int st_id) {
		this.st_id = st_id;
	}

	public String getF_name() {
		return f_name;
	}

	public void setF_name(String f_name) {
		this.f_name = f_name;
	}

	public String getL_name() {
		return l_name;
	}

	public void setL_name(String l_name) {
		this.l_name = l_name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getSt_password() {
		return st_password;
	}

	public void setSt_password(String st_password) {
		this.st_password = st_password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	
	@Override
	public String toString() {
		return "Student [st_id=" + st_id + ", f_name=" + f_name + ", l_name=" + l_name + ", gender=" + gender
				+ ", st_password=" + st_password + ", address=" + address + ", email=" + email + ", course=" + course
				+ "]";
	}

	
	@Override
	public int hashCode() {
		return Objects.hash(st_id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return st_id == other.st_id;
	}

	@Override
	public int compareTo(Student o) {
		if(this.st_id<o.st_id)
			return -1;
		if(this.st_id>o.st_id)
			return 1;
		return 0;
	}

}
