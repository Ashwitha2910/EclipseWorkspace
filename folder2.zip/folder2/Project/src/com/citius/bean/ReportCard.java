package com.citius.bean;

import java.util.Objects;

public class ReportCard implements Comparable<ReportCard> {

	private int rc_id;
	private int stud_roll_no;
	private int Score;
	private String date_of_Exam;
	
	public int getReportCard() {
		return rc_id;
	}
	public void setReportCard(int reportCard) {
		this.rc_id = reportCard;
	}
	public ReportCard() {
		super();
	}

	public ReportCard(int rc_id) {
		super();
		this.rc_id = rc_id;
	}

	public ReportCard(int rc_id, int stud_roll_no, int score, String date_of_Exam) {
		super();
		this.rc_id = rc_id;
		this.stud_roll_no = stud_roll_no;
		Score = score;
		this.date_of_Exam = date_of_Exam;
	}



	public int getRc_id() {
		return rc_id;
	}

	public void setRc_id(int rc_id) {
		this.rc_id = rc_id;
	}

	public int getStud_roll_no() {
		return stud_roll_no;
	}

	public void setStud_roll_no(int stud_roll_no) {
		this.stud_roll_no = stud_roll_no;
	}

	public int getScore() {
		return Score;
	}

	public void setScore(int score) {
		Score = score;
	}

	public String getDate_of_Exam() {
		return date_of_Exam;
	}

	public void setDate_of_Exam(String date_of_Exam) {
		this.date_of_Exam = date_of_Exam;
	}

	
	@Override
	public String toString() {
		return "ReportCard [rc_id=" + rc_id + ", stud_roll_no=" + stud_roll_no + ", Score=" + Score + ", date_of_Exam="
				+ date_of_Exam + "]";
	}

	
	

	@Override
	public int hashCode() {
		return Objects.hash(rc_id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReportCard other = (ReportCard) obj;
		return rc_id == other.rc_id;
	}

	@Override
	public int compareTo(ReportCard o) {
		if(this.rc_id<o.rc_id)
			return -1;
		if(this.rc_id>o.rc_id)
			return 1;
		return 0;
	}
	
}
