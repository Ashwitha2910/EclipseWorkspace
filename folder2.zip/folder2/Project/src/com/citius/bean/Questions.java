package com.citius.bean;

import java.util.Objects;

public class Questions implements Comparable<Questions> {
	private int q_id;
	private String que;
	private int exam_id;
	private String opt1;
	private String opt2;
	private String opt3;
	private String correct_ans;
	
	public Questions() {
		super();
	}
	
	public Questions(int q_id) {
		super();
		this.q_id = q_id;
	}

	public Questions(int q_id, String que, int exam_id, String opt1, String opt2, String opt3, String correct_ans) {
		super();
		this.q_id = q_id;
		this.que = que;
		this.exam_id = exam_id;
		this.opt1 = opt1;
		this.opt2 = opt2;
		this.opt3 = opt3;
		this.correct_ans = correct_ans;
	}
	public int getQ_id() {
		return q_id;
	}
	public void setQ_id(int q_id) {
		this.q_id = q_id;
	}
	public String getQue() {
		return que;
	}
	public void setQue(String que) {
		this.que = que;
	}
	public int getExam_id() {
		return exam_id;
	}
	public void setExam_id(int exam_id) {
		this.exam_id = exam_id;
	}
	public String getOpt1() {
		return opt1;
	}
	public void setOpt1(String opt1) {
		this.opt1 = opt1;
	}
	public String getOpt2() {
		return opt2;
	}
	public void setOpt2(String opt2) {
		this.opt2 = opt2;
	}
	public String getOpt3() {
		return opt3;
	}
	public void setOpt3(String opt3) {
		this.opt3 = opt3;
	}
	public String getCorrect_ans() {
		return correct_ans;
	}
	public void setCorrect_ans(String correct_ans) {
		this.correct_ans = correct_ans;
	}
	@Override
	public String toString() {
		return "Questions [q_id=" + q_id + ", que=" + que + ", exam_id=" + exam_id + ", opt1=" + opt1 + ", opt2=" + opt2
				+ ", opt3=" + opt3 + ", correct_ans=" + correct_ans + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(exam_id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Questions other = (Questions) obj;
		return exam_id == other.exam_id;
	}
	@Override
	public int compareTo(Questions o) {
		if(this.exam_id<o.exam_id)
			return -1;
		if(this.exam_id>o.exam_id)
			return 1;
		return 0;
	}
	
	
	
}
