package com.citius.bean;

import java.util.Objects;

public class Exam implements Comparable<Exam> {

	private int e_id;
	private String e_name;
	private String created_by;
	private String subject;
	private String description;
	public int getE_id() {
		return e_id;
	}
	
	public Exam(int e_id) {
		super();
		this.e_id = e_id;
	}

	public Exam(int e_id, String e_name) {
		super();
		this.e_id = e_id;
		this.e_name = e_name;
	}

	public void setE_id(int e_id) {
		this.e_id = e_id;
	}
	public String getE_name() {
		return e_name;
	}
	public void setE_name(String e_name) {
		this.e_name = e_name;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Exam(int e_id, String e_name, String created_by, String subject, String description) {
		super();
		this.e_id = e_id;
		this.e_name = e_name;
		this.created_by = created_by;
		this.subject = subject;
		this.description = description;
	}
	
	public Exam(String e_name, String created_by, String subject, String description) {
		super();
		this.e_name = e_name;
		this.created_by = created_by;
		this.subject = subject;
		this.description = description;
	}

	public Exam() {
		super();
	}
	@Override
	public String toString() {
		return "Exam [e_id=" + e_id + ", e_name=" + e_name + ", created_by=" + created_by + ", subject=" + subject
				+ ", description=" + description + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(e_id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Exam other = (Exam) obj;
		return e_id == other.e_id;
	}
	@Override
	public int compareTo(Exam o) {
		if(this.e_id<o.e_id)
			return -1;
		if(this.e_id>o.e_id)
			return 1;
		return 0;
		
	}
	
	
}
