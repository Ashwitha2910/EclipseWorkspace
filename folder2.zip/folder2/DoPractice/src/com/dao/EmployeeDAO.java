package com.dao;

import java.sql.Connection;
import java.util.List;

import com.model.Employee;

public interface EmployeeDAO {
String SEARCHEMP="select * from EmployeeDetails where eAge>20";
List<Employee> search();

}
