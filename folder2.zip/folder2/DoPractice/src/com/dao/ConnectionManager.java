package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionManager {
	public static Connection connectionMaker() {
	try {
        String url="jdbc:sqlserver://localhost\\MSSQLSERVER;databaseName=EmployeeDB;trustServerCertificate=true;";
        
        Connection connecter=DriverManager.getConnection(url,"sa","password_123");
        return connecter;
	}catch(Exception ex) {
		ex.printStackTrace();
		return null;
	}
}
	public static void closeConnection(Connection connecter) {
		try {
			connecter.close();
		}catch(Exception ex) {
			ex.printStackTrace();
			
		}
	}
}
