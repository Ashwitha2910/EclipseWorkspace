package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.model.Employee;

public class EmployeeDaoImpl{

	
	public List<Employee> search() {
		List<Employee>list=new ArrayList<Employee>();
		Connection connecter = ConnectionManager.connectionMaker();
		try {
			
			PreparedStatement p=connecter.prepareStatement("select * from EmployeeDetails where eAge>20");
			ResultSet res=p.executeQuery();
			while(res.next()) {
				Employee emp=new Employee(res.getInt(1),res.getString(2),res.getString(3),res.getInt(4));
				list.add(emp);
			}
			ConnectionManager.closeConnection(connecter);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return list;
	}

}
