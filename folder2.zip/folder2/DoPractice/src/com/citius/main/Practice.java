package com.citius.main;



import java.sql.Connection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.dao.ConnectionManager;
import com.dao.EmployeeDaoImpl;
import com.model.Employee;

public class Practice {
	public static void main(String[] args) {
		HashMap<Integer,String> hm=new HashMap<Integer,String>();
		hm.put(9, "Ashwitha");
		hm.put(8, "Shishir");
		hm.put(2, "Suksham");
		hm.put(1, "Shravan");
		hm.put(10, "Prajna");
		hm.put(5, "Nidhi");
		System.out.println(hm);
		for (Map.Entry<Integer, String> entry : hm.entrySet()) {
			Integer key = entry.getKey();
			String val = entry.getValue();
			
		}
	
	
//	EmployeeDaoImpl e= new EmployeeDaoImpl();
	Connection connecter=ConnectionManager.connectionMaker();
		EmployeeDaoImpl emp=new EmployeeDaoImpl();
	List<Employee>l=emp.search();
	for (Iterator<Employee> iterator = l.iterator(); iterator.hasNext();) {
		Employee employee = (Employee) iterator.next();
		System.out.println(employee.getEmpName()+"-->"+employee.geteAge());
	}
	ConnectionManager.closeConnection(connecter); 
}
}
