package com.model;

public class Employee {
	private int id;
	private String empName;
	private String eAddress;
	private int eAge;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String geteAddress() {
		return eAddress;
	}
	public Employee(int id, String empName, String eAddress, int eAge) {
		super();
		this.id = id;
		this.empName = empName;
		this.eAddress = eAddress;
		this.eAge = eAge;
	}
	public void seteAddress(String eAddress) {
		this.eAddress = eAddress;
	}
	public int geteAge() {
		return eAge;
	}
	public void seteAge(int eAge) {
		this.eAge = eAge;
	}
	public Employee() {
		super();
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", empName=" + empName + ", eAddress=" + eAddress + ", eAge=" + eAge + "]";
	}
	
	

}
