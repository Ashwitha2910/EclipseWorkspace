package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/hi")
public class HomeController {

	@RequestMapping("/message")
	@ResponseBody
	public String getMessage() {
		System.out.println("Helloo..");
		return "Good Morning";
	}
}
