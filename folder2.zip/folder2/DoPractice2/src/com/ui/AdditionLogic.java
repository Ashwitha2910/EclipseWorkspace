package com.ui;


public class AdditionLogic<T extends Number> extends AdditionOfNumbers<T>{

	@Override
	public <T extends Number> T add(T n1,T n2) {
		
		    if (n1 == null || n2 == null) {
		        return null;
		    }
		    if (n1 instanceof Integer) {
		        return (T) (Integer)((Integer)n1+(Integer)n2);
		    }
		    if (n1 instanceof Long) {
		        return (T) Long.valueOf(n1.longValue() + n2.longValue());
		    }
		    if (n1 instanceof Float) {
		        return (T) Float.valueOf(n1.floatValue() + n2.floatValue());
		    }
		    if (n1 instanceof Double) {
		        return (T) Double.valueOf(n1.doubleValue() + n2.doubleValue());
		    }
		    return null;
		}
		
	}
