package com.ui;

public class Main {

	public static void main(String[] args) {
		AdditionOfNumbers result=new AdditionLogic();
		System.out.println("Sum is:"+result.add(15,15));

//		NewClass n=new NewClass();
//		System.out.println(n.Addition(10, 10));
	}

}
