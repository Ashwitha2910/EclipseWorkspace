package com.ui;

public class NewClass {

	public <T extends Number> T Addition(T num1,T num2){
		if (num1 == null || num2 == null) {
	        return null;
	    }
	    if (num1 instanceof Integer) {
	        return (T) Integer.valueOf(num1.intValue() + num2.intValue());
	    }
	    if (num1 instanceof Long) {
	        return (T) Long.valueOf(num1.longValue() + num2.longValue());
	    }
	    if (num1 instanceof Float) {
	        return (T) Float.valueOf(num1.floatValue() + num2.floatValue());
	    }
	    if (num1 instanceof Double) {
	        return (T) Double.valueOf(num1.doubleValue() + num2.doubleValue());
	    }
	    return null;
		
	}
}
