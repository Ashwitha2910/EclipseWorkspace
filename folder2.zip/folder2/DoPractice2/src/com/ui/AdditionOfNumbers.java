package com.ui;

public abstract class AdditionOfNumbers<T> {
	public abstract <T extends Number> T add(T obj1,T obj2);
}
