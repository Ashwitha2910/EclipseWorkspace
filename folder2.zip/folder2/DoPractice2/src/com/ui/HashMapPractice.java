package com.ui;

import java.util.HashMap;

public class HashMapPractice {
	public static void main(String[] args) {
		HashMap<String, String> hm= new HashMap<String,String>();
		hm.put("India","Delhi");
		hm.put("SwitzerLand", "Bern");
		hm.put("South Korea", "Seoul");
	}
	
}
