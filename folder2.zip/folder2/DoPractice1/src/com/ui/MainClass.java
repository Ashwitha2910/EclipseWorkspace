package com.ui;
import java.util.Iterator;
import java.util.List;

import com.ui.DoMath;
public class MainClass {

	public static void main(String[] args) {
		int[] array={24, 26, 29, 30, 35};
		int len=array.length;
		int x=array[0];
		int y=array[len-1];
		int flag=0;
		
		
			
			for(int j=x+1;j<y;j++) {
				
				for(int i=0;i<array.length;i++) {
					
				if(j==array[i])
				{
					flag=1;
					break;
				}
				
			}
				if(flag==0) {
					System.out.println(j);
		}
			flag=0;
}
		
//	DoMath d=new DoMath();
//	List<Integer>l=d.findMissingNumbers(array);
//	for (Iterator iterator = l.iterator(); iterator.hasNext();) {
//		Integer integer = (Integer) iterator.next();
//		System.out.println(integer);
//		
//	}
//	
	
	}
}
