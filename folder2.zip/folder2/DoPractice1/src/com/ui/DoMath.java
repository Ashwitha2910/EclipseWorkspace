package com.ui;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class DoMath {

	public List<Integer> findMissingNumbers(int[] arr){
		List<Integer>list=new ArrayList<Integer>();
		int len=arr.length;
		int x=arr[0];
		int y=arr[len-1];
		int flag=0;
		
		
			
			for(int j=x+1;j<y;j++) {
				for(int i=0;i<arr.length;i++) {
				if(j==arr[i])
				{
					flag=1;
					break;
				}
				
			}
				if(flag==0) {
					list.add(j);
		}
			flag=0;
}
			
		return list;
	}
}
