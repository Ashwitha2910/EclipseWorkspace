package com.citius.bean;
import com.citius.ui.Circle;

public class CircleList implements List<Circle> {

	@Override
	public void add(Circle obj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(int position, Circle obj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Circle remove(int position) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
