package com.citius.bean;

public class GeneralList<T> implements List<T> {
	Object[] arr=new Object[10];
	Object val;
	int len=0;
	@Override
	public void add(T obj) {
		for(int j=1;j<arr.length;j++)
		{
			len++;
		}
		if(len==10)
			len=len+1;
//		arr=arr[len];
	}

	@Override
	public void insert(int position, T obj) {
		for(int i=position;i<arr.length;i++)
		{
			arr[i+1]=arr[i];
			arr[position]=val;
		}
		
	}

	@Override
	public T remove(int position) {
		for(int i=position;i<arr.length;i++)
		{
			arr[i]=arr[i+1];
			
			
		}
		return null;
	}

}
