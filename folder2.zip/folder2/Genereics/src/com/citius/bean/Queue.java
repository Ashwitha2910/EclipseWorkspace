package com.citius.bean;
//Generic interface
public interface Queue<T> {
	void add(T obj);
	T remove();
}
