package com.citius.bean;

public class AssignmentClient {
	public static void main(String[] args) {
		GeneralList<Integer> l1=new GeneralList<>();
//		l1.val=9;
		l1.insert(0, 5);
		l1.insert(1, 8);
		l1.insert(2, 6);
		l1.insert(3,7);
		l1.remove(2);

		System.out.println(l1.arr);
	}
}
