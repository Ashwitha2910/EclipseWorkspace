package com.citius.ui;

public class IntStackImpl {
	  int[] arr;
	    int index;

	    public IntStackImpl() {
	        arr = new int[10];
	    }

	    public void push(int b) {
	        arr[index++]=b;
	    }

	    public int pop() {
	        return arr[--index];
	    }
}
