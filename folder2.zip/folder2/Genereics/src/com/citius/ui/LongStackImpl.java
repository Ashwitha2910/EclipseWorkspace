package com.citius.ui;

public class LongStackImpl {
	Long[] arr;
    int index;

    public LongStackImpl() {
        arr = new Long[10];
    }

    public void push(Long b) {
        arr[index++]=b;
    }

    public Long pop() {
        return arr[--index];
    }
}
