package com.citius.ui;
public class ByteStackImpl {
    byte[] arr;
    int index;

    public ByteStackImpl() {
        arr = new byte[10];
    }

    public void push(byte b) {
        arr[index++]=b;
    }

    public byte pop() {
        return arr[--index];
    }
}