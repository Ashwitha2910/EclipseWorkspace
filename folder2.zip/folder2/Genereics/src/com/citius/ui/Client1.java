package com.citius.ui;

import com.citius.bean.QueueImpl;

public class Client1 {

	public static void main(String[] args) {
		ByteStackImpl impl1=new ByteStackImpl();
		
		impl1.push((byte)10);
		impl1.push((byte)20);
		byte v1=25;
		impl1.push(v1);
		
		System.out.println("Byte Stack");

		System.out.println(impl1.pop());
		System.out.println(impl1.pop());
		System.out.println(impl1.pop());
		
		IntStackImpl impl2=new IntStackImpl();
		impl2.push(100);
		impl2.push(200);
		impl2.push(300);
		
		System.out.println("Int Stack");
		System.out.println(impl2.pop());
		System.out.println(impl2.pop());
		System.out.println(impl2.pop());

		CircleStackmpl impl3=new CircleStackmpl();
		impl3.push(new Circle(1000));
		impl3.push(new Circle(2000));
		Circle c=new Circle(3000);
		impl3.push(c);
		
		ObjectStackImpl<Integer> impl4=new ObjectStackImpl<>();
		impl4.push(new Integer(90));
		impl4.push(new Integer(100));
		impl4.push(new Integer(200));
		
		Integer obj=impl4.pop();
		System.out.println(obj.doubleValue());
		
		Integer obj1=impl4.pop();
		System.out.println(obj1.doubleValue());

		Integer obj2=impl4.pop();
		System.out.println(obj2.doubleValue());
		
		ObjectStackImpl<Circle> impl5=new ObjectStackImpl<>();
		impl5.push(new Circle(20));
		impl5.push(new Circle(30));
		impl5.push(new Circle(40));
		
		Circle obj3=impl5.pop();
		System.out.println(obj3.toString());
		
		Circle obj4=impl5.pop();
		System.out.println(obj4.toString());

		Circle obj5=impl5.pop();
		System.out.println(obj5.toString());
		
		QueueImpl<Circle> impl6=new QueueImpl<>();
		impl6.add(new Circle(10));
		Circle c1=impl6.remove();
		

}
}
