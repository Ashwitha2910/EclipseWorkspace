package com.citius.ui;

public class CircleStackmpl {
	Circle[] arr;
    int index;

    public CircleStackmpl() {
        arr = new Circle[10];
    }

    public void push(Circle b) {
        arr[index++]=b;
    }

    public Circle pop() {
        return arr[--index];
    }
}
