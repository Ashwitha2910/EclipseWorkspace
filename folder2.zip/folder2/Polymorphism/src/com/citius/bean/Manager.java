package com.citius.bean;

public class Manager extends Employee{
	int empCount;
	
	@Override
	public double computeNetSalary()
	{
		return super.basicSalary+super.computeAllowance()+(this.empCount*1000);
	}
}
