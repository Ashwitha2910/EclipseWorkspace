package com.citius.bean;

public class Client {
	public static void main(String[] args) {
		Employee employee=new Employee();
		employee.basicSalary=10000;
		System.out.println(employee.computeAllowance());
		System.out.println(employee.computeAllowance(10));
		System.out.println(employee.computeNetSalary());
		
		Manager manager=new Manager();
		manager.basicSalary=10000;
		manager.empCount=5;
//		System.out.println("Manager Allowance "+manager.computeAllowance());
//		System.out.println(manager.computeAllowance(10));
		System.out.println(manager.computeNetSalary());
		
	}
}
