package com.citius.bean;

public class C {
	private void greet(int n)
	{
		System.out.println("Good Morning "+n+"times");
	}
	
	public static void goodBye()
	{
		System.out.println("GoodBye");
	}
}
