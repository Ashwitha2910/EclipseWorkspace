package com.citius.bean;

public class Employee {
	private int id;
	private String name;
	double basicSalary;
	
	public double computeAllowance() {
		return this.basicSalary*0.45;
	}
	
	public double computeAllowance(int extraHours)
	{
		return (this.basicSalary*0.45)+(extraHours*500);
	}
	
	public double computeNetSalary()
	{
		return this.basicSalary+this.computeAllowance();
	}
}
