package com.citius.bean;

public class A {
	protected void f1(int a) //protected fns accessible only by friends
	{
		System.out.println("f1 in A "+a);
	}
	
	public void f1(int a,float b)
	{
		System.out.println("f1 in A "+a+","+b);
	}
	private int f1(int a,char ch)
	{
		System.out.println("f1 in A"+a+","+ch);
		return a*a;
	}
	
	static void f2(double b)
	{
		System.out.println("f2 in A"+ b);
	}
	void f2(char b)//static methods can be overloaded
	{
		System.out.println("f2 in A"+ b);
	}
}
