package com.citius.bean;

public class D extends C{
	
	@Override
	protected void greet(int c)
	{
		System.out.println("Good Evening"+ c+ "times");
	}
	public static void goodBye()
	{
		System.out.println("Gooooood Bye");
	}
}
