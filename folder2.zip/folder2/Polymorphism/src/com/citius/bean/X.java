package com.citius.bean;

public class X {

}
