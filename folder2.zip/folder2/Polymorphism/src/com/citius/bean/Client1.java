package com.citius.bean;

public class Client1 {
	public static void main(String[] args) {
		X obj=new x();
		obj.
	}
}
