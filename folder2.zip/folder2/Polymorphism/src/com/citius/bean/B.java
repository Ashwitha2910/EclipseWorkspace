package com.citius.bean;

public class B extends A {
	public void f1(double a,boolean b)
	{
		System.out.println("f1 in B "+a+","+b);
	}
}
