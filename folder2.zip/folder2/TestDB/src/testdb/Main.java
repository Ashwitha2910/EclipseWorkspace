package testdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
public class Main {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		String url="jdbc:sqlserver://localhost\\MSSQLSERVER;databaseName=DBTraining;trustServerCertificate=true;";
		Connection con=DriverManager.getConnection(url,"sa","password_123");//getting connection
		System.out.println("Connected");
		
		Statement st=con.createStatement();
		String sql="insert into test2 values(1,'Ram')";
		
		int a=st.executeUpdate(sql);
		System.out.println(a);

	}

}
