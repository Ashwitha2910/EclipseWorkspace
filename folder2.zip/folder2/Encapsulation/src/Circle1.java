public class Circle1 {
    private int radius;  //Instance variable
    
    void setRadius(int radius)
    {
    	this.radius=radius;
    }
    int getRadius()
    {
    	return radius;
    }
    
    double computeArea() {
        double area;
        area=3.14*radius*radius;
        return area;
    }
}
