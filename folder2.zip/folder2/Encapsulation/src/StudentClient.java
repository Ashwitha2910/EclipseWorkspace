
public class StudentClient {

	public static void main(String[] args) {
		Student s1=new Student();
		s1.setMark1(87);
		s1.setMark2(77);
		s1.setMark3(90);
		System.out.println(s1.getTotal());
		System.out.println("Average: "+s1.getAverage());
		System.out.println("Grade: "+s1.computeGrade());
		
		Student s2=new Student();
		s2.setMark1(45);
		s2.setMark2(87);
		s2.setMark3(56);
		System.out.println(s2.getTotal());
		System.out.println("Average: "+s2.getAverage());
		System.out.println("Grade: "+s2.computeGrade());
		
		s1=null;
		s2=null;

	}

}
