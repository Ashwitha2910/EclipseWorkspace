
public class CircleClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle1 c1;
		c1=new Circle1();
		c1.setRadius(10);
		System.out.println(c1.computeArea());
		
		c1.setRadius(15);
		System.out.println(c1.computeArea());

		Circle1 c2;
		c2=new Circle1();
		c2.setRadius(20);
		System.out.println(c2.computeArea());
		
		Circle1 c3=new Circle1();
		c3.setRadius(16);
		System.out.println(c3.computeArea());
	
		c1=null;
		c2=null;
		c3=null;
	}

}
