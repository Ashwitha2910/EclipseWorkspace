
public class Employee {
	private double basicSalary;
	private char grade;
	
	
	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}

	public char getGrade() {
		return grade;
	}

	public void setGrade(char grade) {
		this.grade = grade;
	}

	double computwAllowance() {
		double result;
		switch(grade)
		{
		case 'A':
			result=basicSalary*0.40; 
			break;
		case 'B': 
			result=basicSalary*0.35;
			break;
		case 'C': 
			result=basicSalary*0.25;
			break;
		default:
			result=basicSalary;
//		double result=basicSalary*0.35;
//		return result;
	}
		return result;
	}
	
	double computeTax() {
		return basicSalary*0.10;
	}
}
