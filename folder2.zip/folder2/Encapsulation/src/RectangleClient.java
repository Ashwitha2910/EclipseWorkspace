
public class RectangleClient {

	public static void main(String[] args) {
		Rectangle r1=new Rectangle();
		r1.setLength(5);
		r1.setWidth(8);
		System.out.println("The area is: "+r1.computeArea());
		
		r1=null;
	}

}
