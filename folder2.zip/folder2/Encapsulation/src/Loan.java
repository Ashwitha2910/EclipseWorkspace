
public class Loan {
	private double loanAmount;
	private int tenure;
	private float interestRate;
	
	
	
	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public float getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(float interestRate) {
		this.interestRate = interestRate;
	}

	double getInterestAmount()
	{
		return loanAmount*tenure*interestRate;
	}
	
	double getRepayable()
	{
		return loanAmount+getInterestAmount();
		
	}
	
	double getEMI()
	{
		return getRepayable()/interestRate;
	}
}
