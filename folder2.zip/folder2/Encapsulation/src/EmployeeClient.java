
public class EmployeeClient {

	public static void main(String[] args) {
		Employee e1=new Employee();
		
		e1.setBasicSalary(10000);
		e1.setGrade('A');
		System.out.println(e1.computwAllowance());
		System.out.println(e1.computeTax());
		
		Employee e2=new Employee();
		e2.setBasicSalary(40000);
		e2.setGrade('C');
		System.out.println(e2.computwAllowance());
		System.out.println(e2.computeTax());

		e1=null;
		e2=null;
	}

}
