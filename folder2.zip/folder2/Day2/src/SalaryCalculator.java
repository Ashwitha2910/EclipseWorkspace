
public class SalaryCalculator {
	double getAllowance(double basic,char grade)
	{
		double result=0.0;
		switch(grade)
		{
		case 'A':
			result=basic*0.40; 
			break;
		case 'B': 
			result=basic*0.35;
			break;
		case 'C': 
			result=basic*0.25;
			break;
		default:
			result=basic;
		}
		return result;
	}
}
