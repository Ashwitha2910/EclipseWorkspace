
public class Loan {
	double loanAmount;
	int tenure;
	float interestRate;
	
	double getInterestAmount()
	{
		return loanAmount*tenure*interestRate;
	}
	
	double getRepayable()
	{
		return loanAmount+getInterestAmount();
		
	}
	
	double getEMI()
	{
		return getRepayable()/interestRate;
	}
}
