
public class LoanMain {

	public static void main(String[] args) {
		Loan l1=new Loan();
		l1.interestRate=5;
		l1.tenure=3;
		l1.loanAmount=50000;
		System.out.println("Total Interest: "+l1.getInterestAmount());
		System.out.println("Total Repayable: "+l1.getRepayable());
		System.out.println("Total EMI: "+l1.getEMI());
		
		l1=null;



	}

}
