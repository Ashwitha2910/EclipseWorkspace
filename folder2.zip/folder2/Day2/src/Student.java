
public class Student {
	int mark1,mark2,mark3;//data member//instance variable
	int getTotal() //member function
	{
		return mark1+mark2+mark3;
	}
}
