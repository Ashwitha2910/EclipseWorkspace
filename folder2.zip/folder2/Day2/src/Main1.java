
public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c1;
		c1=new Circle();
		System.out.println(c1.radius);
		System.out.println(c1.computeArea());
		
		c1.radius=15;
		System.out.println(c1.computeArea());

		Circle c2;
		c2=new Circle();
		c2.radius=20;
		System.out.println(c2.computeArea());
		
		Circle c3=new Circle();
		c3.radius=14;
		System.out.println(c3.computeArea());
	
		c1=null;
		c2=null;
		c3=null;

	}

}
