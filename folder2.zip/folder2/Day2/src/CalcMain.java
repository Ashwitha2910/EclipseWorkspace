
public class CalcMain {

	public static void main(String[] args) {
		SalaryCalculator c1=new SalaryCalculator();
		System.out.println(c1.getAllowance(40000,'A'));
		
		c1=null;

	}

}
