public class Circle {
    int radius;                //Instance variable
    
    double computeArea() {
        double area;
        area=3.14*radius*radius;
        return area;
    }
}
