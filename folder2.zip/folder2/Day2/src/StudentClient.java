
public class StudentClient {

	public static void main(String[] args) {
		Student s1=new Student();
		s1.mark1=65;
		s1.mark2=77;
		s1.mark3=66;
		System.out.println(s1.getTotal());
		
		Student s2=new Student();
		s2.mark1=45;
		s2.mark2=87;
		s2.mark3=56;
		System.out.println(s2.getTotal());
		
		s1=null;
		s2=null;

	}

}
